"""Build and reopen the bounded E5-1A review archive; no scientific execution."""
import csv
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = '131daa541ac37e54d43b29cd3bfc12ba83c3b91d'
DOC = 'docs/physics_decisions/hr4e5/e5_1'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

spec = importlib.util.spec_from_file_location('provenance_v2', ROOT / 'Filament_python/tools/hpc_ops/provenance_v2.py')
prov = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prov)

def main():
    sha = git('rev-parse', 'HEAD').decode().strip()
    changed = git('diff', '--name-only', BASE, sha).decode().splitlines()
    items, records = {}, []

    def add(path, data, role, repo_path=None):
        if path in items:
            raise ValueError(f'duplicate {path}')
        items[path] = data
        rec = dict(path=path, sha256=hashlib.sha256(data).hexdigest(), role=role,
                   source_commit=sha, hash_scope='raw_bytes')
        if repo_path:
            blob = git('rev-parse', f'{sha}:{repo_path}').decode().strip()
            rec.update(repo_path=repo_path, git_blob_oid=blob,
                       canonical_lf_sha256=prov.canonical_lf_sha256(git('cat-file', 'blob', blob)),
                       source_hash_scope=prov.TRACKED_HASH_SCOPE)
        else:
            rec.update(generator='package_review.py or identified local test log', runtime_commit=sha,
                       git_blob_oid=None)
        records.append(rec)

    for p in changed:
        if p.startswith(DOC + '/') and Path(p).name.startswith('E5_1A_'):
            add('reports/' + Path(p).name, git('show', f'{sha}:{p}'), 'report', p)
        elif p.startswith('Filament_python/'):
            add('source/' + p, git('show', f'{sha}:{p}'), 'changed_runtime_or_test', p)

    dependencies = [
        'Filament_python/KHz_filament/hr4e5s_streaming.py',
        'Filament_python/KHz_filament/hr4e5s_s3.py',
        'Filament_python/KHz_filament/hr4d_pulse_lifecycle.py',
        'Filament_python/KHz_filament/hr4c_state.py',
        'Filament_python/KHz_filament/hr4e_timestep.py',
        'Filament_python/KHz_filament/propagate.py',
        'Filament_python/KHz_filament/runner.py',
        'Filament_python/tools/hpc_ops/provenance_v2.py',
    ]
    for p in dependencies:
        if 'source/' + p not in items:
            add('source/' + p, git('show', f'{sha}:{p}'), 'fixed_dependency_full_file', p)
    for filename in ['formal_hr4e5_e5_0_freeze_candidate.json', 'formal_hr4e5_e5_0_authority_contract.json']:
        p = 'docs/physics_decisions/hr4e5/e5_0/' + filename
        add('evidence/frozen_' + filename, git('show', f'{sha}:{p}'), 'unchanged_historical_input_contract', p)
    add('patches/base_to_review.diff', git('diff', '--no-ext-diff', BASE, sha), 'baseline_diff')
    add('patches/base_to_review.stat', git('diff', '--stat', BASE, sha), 'baseline_stat')
    protected = ['Filament_python/KHz_filament/propagate.py',
                 'Filament_python/KHz_filament/runner.py',
                 'Filament_python/KHz_filament/nonlinear.py',
                 'Filament_python/KHz_filament/ionization',
                 'Filament_python/KHz_filament/raman.py',
                 'Filament_python/KHz_filament/linear.py',
                 'Filament_python/KHz_filament/linear_full.py',
                 'Filament_python/KHz_filament/config.py',
                 'Filament_python/KHz_filament/config_schema.py',
                 'Filament_python/KHz_filament/config_normalize.py',
                 'docs/physics_decisions/hr4e5/e5_0']
    diff = git('diff', '--name-only', BASE, sha, '--', *protected).decode()
    if diff.strip():
        raise ValueError('protected files changed: ' + diff)
    add('evidence/baseline_scope.json', json.dumps(dict(base=BASE, code_review_commit=sha,
        branch=git('branch', '--show-current').decode().strip(), protected_paths=protected,
        protected_diff=diff, scientific_operators_changed=False, narrow_streaming_extension=False, formal_status='E5_1A_PARTIAL'), indent=2).encode(), 'scope_audit')
    evidence = ROOT / '.e5_1a_review' / 'evidence'
    if not evidence.is_dir():
        raise ValueError('missing curated evidence directory')
    for p in sorted(evidence.rglob('*')):
        if p.is_file():
            if p.stat().st_size > 16 * 1024**2:
                raise ValueError('evidence exceeds tiny-artifact limit: ' + str(p))
            add('evidence/' + p.relative_to(evidence).as_posix(), p.read_bytes(), 'local_validation')
    readme = ROOT / '.e5_1a_review' / 'WEB_REVIEW_README.md'
    add('WEB_REVIEW_README.md', readme.read_bytes(), 'reading_guide')
    add('evidence/package_review.py', Path(__file__).read_bytes(), 'archive_generator')
    index = dict(schema='filament.e5_1a.web_review.v1', hash_scope='classified_by_record',
                 base_commit=BASE, source_commit=sha, objects=records)
    items['WEB_REVIEW_INDEX.json'] = (json.dumps(index, indent=2) + '\n').encode()
    items['SHA256SUMS.txt'] = ''.join(f'{hashlib.sha256(data).hexdigest()}  {p}\n'
        for p, data in sorted(items.items())).encode()
    dest = ROOT / 'review_bundles' / 'HR4E5_E5_1A_STREAMING_IMPLEMENTATION_WEB_REVIEW_20260916.zip'
    dest.parent.mkdir(exist_ok=True)
    if dest.exists():
        dest = dest.with_stem(dest.stem + '_' + sha[:12])
    with zipfile.ZipFile(dest, 'x', zipfile.ZIP_DEFLATED) as archive:
        for p, data in sorted(items.items()):
            archive.writestr(p, data)
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names))
        for name in names:
            path = PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
            assert archive.read(name)
        actual = json.loads(archive.read('WEB_REVIEW_INDEX.json'))
        assert {r['path'] for r in actual['objects']} == set(names) - {'WEB_REVIEW_INDEX.json', 'SHA256SUMS.txt'}
        for rec in actual['objects']:
            assert hashlib.sha256(archive.read(rec['path'])).hexdigest() == rec['sha256']
        sums = archive.read('SHA256SUMS.txt').decode().splitlines()
        assert len(sums) == len(names) - 1
        for line in sums:
            digest, name = line.split('  ', 1)
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest
        for name in names:
            if name.endswith('.json'):
                json.loads(archive.read(name))
            if name.endswith('.csv'):
                rows = list(csv.reader(io.StringIO(archive.read(name).decode('utf-8-sig'))))
                assert rows and all(len(r) == len(rows[0]) for r in rows)
        extracted = ROOT / '.e5_1a_review' / ('extracted_' + sha[:12])
        extracted.mkdir(exist_ok=False)
        archive.extractall(extracted)
        for name, expected in items.items():
            assert (extracted / name).read_bytes() == expected
        links_checked = 0
        for name in ['WEB_REVIEW_README.md'] + [n for n in names if n.startswith('reports/') and n.endswith('.md')]:
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', archive.read(name).decode('utf-8-sig')):
                target = target.strip('<>').split('#', 1)[0]
                if not target or '://' in target:
                    continue
                links_checked += 1
                assert ((extracted / name).parent / target).exists(), (name, target)
    result = dict(zip=str(dest), sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
                  source_commit=sha, entries=len(items), crc='PASS', index_coverage='PASS',
                  checksums='PASS', json_csv_structure='PASS', paths_unique_safe='PASS',
                  extraction_bytes='PASS', markdown_links_checked=links_checked)
    (ROOT / '.e5_1a_review' / 'archive_validation.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
