"""Bounded document/CSV/link validation for the local E5-1A delivery."""
import csv
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/physics_decisions/hr4e5/e5_1'

def main():
    parsed = []
    for path in sorted(DOC.glob('E5_1A_*.json')):
        json.loads(path.read_text(encoding='utf-8-sig'))
        parsed.append(path.name)
    contract = json.loads((DOC / 'E5_1A_CONTRACT.json').read_text(encoding='utf-8-sig'))
    assert contract['max_campaign_live_bytes'] == 300 * 1024**3 == 322122547200
    assert contract['final_output_budget_bytes'] == 64 * 1024**3 == 68719476736
    assert contract['formal_execution_authorized'] is False
    assert contract['hpc_scientific_execution_authorized'] is False
    assert contract['resource_execution_gate'] == 'NOT_RELEASED'
    path = DOC / 'E5_1A_RESOURCE_BUDGET.csv'
    with path.open(encoding='utf-8-sig', newline='') as stream:
        raw = list(csv.reader(stream))
    assert raw and all(len(row) == len(raw[0]) for row in raw)
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    stages = {}
    for row in rows:
        assert row['unit'] == 'bytes'
        quantity, item_bytes, total = map(int, (row['quantity'], row['bytes_each'], row['total_bytes']))
        assert quantity * item_bytes == total, row
        stages[row['stage']] = stages.get(row['stage'], 0) + total
    broken = []
    checked = 0
    for path in DOC.glob('E5_1A_*.md'):
        text = path.read_text(encoding='utf-8-sig')
        assert text.strip(), path
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
            target = target.strip('<>').split('#', 1)[0]
            if not target or '://' in target:
                continue
            checked += 1
            if not (path.parent / target).exists():
                broken.append([path.name, target])
    assert not broken, broken
    subprocess.run(['git', '-C', str(ROOT), 'diff', '--check'], check=True)
    result = dict(json_parsed=parsed, csv_rows=len(rows), stage_totals_bytes=stages,
                  markdown_links_checked=checked, broken_links=broken, diff_check='PASS')
    dest = ROOT / '.e5_1a_review/evidence/delivery_validation.json'
    dest.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
