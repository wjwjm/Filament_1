"""Assemble executed local results without upgrading incomplete A contracts."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
doc=root/'docs/physics_decisions/hr4e5/e5_1'
evidence=root/'.e5_1a_review/evidence'
rows=[
('A01','PASS','baseline_scope.json','Fixed base and unchanged protected scientific/config/LUT/old entry paths; no narrow core extension.'),
('A02','PASS_FIXTURE','integrated_fixture.json','N3/K32 optical test double with independent Batch/Streaming trajectories; not three-pulse real optical exact.'),
('A03','PASS_FIXTURE','integrated_fixture.json','Nonzero PRE velocities carried by each trajectory and included in actual exact.'),
('A04','PASS_FIXTURE','integrated_fixture.json','Original worker hydro-start events precede optical complete; CPU event-driven consumer, not GPU overlap.'),
('A05','PARTIAL','final_new_tests.log','Original real optical/state/sink/hook tested; formal config/source/LUT identity and integrated R/C real-driver binding incomplete.'),
('A06','PASS_LOCAL_BOUNDARY','final_new_tests.log','Complete/partial final replay and old durable POST protection tested; no power-loss claim.'),
('A07','PARTIAL','final_new_tests.log','Actual child payload/hash and missing READY reconstruction checked; full pointer/index/fork/stale-epoch transition matrix incomplete.'),
('A08','PASS_FIXTURE','integrated_fixture.json','1344 actual screen arrays,27 ledgers,3 optical arrays; missing-object/dtype/nonfinite/difference unit refusal. Formal callback inventory gate incomplete.'),
('A09','PARTIAL','final_new_tests.log','Durable prerequisite and refusal checks apply to bounded call paths; universal formal writer/ownership and pair-recovery integration incomplete.'),
('A10','PASS_FIXTURE','integrated_fixture.json','Owned parent payload reclaimed; successor opens independently and candidate terminal retained; not authorization for formal data GC.'),
('A11','PASS_LOCAL_BOUNDARY','final_new_tests.log','Actual subprocess exit after unlink plus durable-intent recovery and unknown-missing refusal; full pair handoff restart remains A07 gap.'),
('A12','PASS_LOCAL_BOUNDARY','final_new_tests.log','Hardlink/traversal/prefix/reparse-equivalent/identity replacement refusal; platform mock is identified in test.'),
('A13','PASS_LOCAL_BOUNDARY','final_new_tests.log','Exact 300GiB constant and oversize refusal; no 300GiB allocation or CLI introduced.'),
('A14','PARTIAL','final_new_tests.log','Process reservation competition/quota/drop/path accounting tested; PRE0/successor helpers not enforced behind a universal admission entry.'),
('A15','PARTIAL','final_new_tests.log','Scalar output cap/extra output refusal and actual fixture terminal reopen; formal retention/role registration integration incomplete.'),
('A16','PASS_LOCAL_BOUNDARY','integrated_fixture.json','NEW_PROCESS_PERSISTENT_RESUME only after completed pair1, reclaimed parent arrays and exited original process; compared with independent uninterrupted run.'),
('A17','PARTIAL','budget_model.json','299676844288-byte peak/47504725760-byte final model aligns fixture file layout; full formal driver enforcement and host RSS qualification absent.'),
('A18','PASS_LOCAL_BOUNDARY','final_legacy_regression.log','34 existing Streaming/HR4D tests; three local 8048-record prototype writes only, not full lifecycle/HPC stress.'),
]
runs=[]
for name,command in [
 ('final_backend.log','run_local_tests.ps1 -Mode backend'),
 ('final_sanity.log','run_local_tests.ps1 -Mode sanity'),
 ('final_legacy_regression.log',"run_local_tests.ps1 -Mode targeted -TargetedFilter 'test_hr4e5s_streaming or test_hr4d_pulse_lifecycle'"),
 ('final_new_tests.log',"run_local_tests.ps1 -Mode targeted -TargetedFilter test_hr4e5_e5_1a"),
 ('final_compile.log','explicit interpreter -s -B -m compileall Filament_python/KHz_filament'),
]:
    p=evidence/name
    text=p.read_text(encoding='utf-8-sig')
    matches=re.findall(r'(\d+) passed(?:, (\d+) deselected)?(?: in ([\d.]+)s)?',text)
    assert not re.search(r'\d+ failed|ERROR collecting|SyntaxError',text),name
    record=dict(command=command,exit_code=0,result='PASS',artifact='evidence/'+name)
    if matches:
        n,d,t=matches[-1];record.update(passed=int(n),deselected=int(d or 0),duration_s=float(t) if t else None)
    runs.append(record)
integrated=json.loads((evidence/'integrated_fixture.json').read_text())
result=dict(schema='filament.hr4e5.e5_1a_test_results.v1',status='E5_1A_PARTIAL',
 blocker='FORMAL_DRIVER_AND_RECOVERY_QUALIFICATION',base_commit='131daa541ac37e54d43b29cd3bfc12ba83c3b91d',
 interpreter=r'C:\Users\wangj\.conda\envs\filament-local-test\python.exe',gpu_enabled=False,
 executed_runs=runs,acceptance=[dict(id=i,result=s,evidence=['evidence/'+e],limitation=l) for i,s,e,l in rows],
 integrated_fixture=integrated,
 not_tested=['GPU','Slurm','S5','K8048 scientific arrays','site quota/RSS/VRAM/allocated disk blocks','cross allocation/node/power loss','complete interrupted formal pair/handoff coordinator'],
 historical_failed_attempts=['initial_new_tests.log','integrated_attempt1.log','final_new_attempt1.log','final_new_attempt2.log'],
 validation_note='Final logs apply to code content committed in review SHA; precommit worktree test, not an HPC execution SHA. Initial failures retained as chronology.')
(doc/'E5_1A_TEST_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'runs':runs,'acceptance_rows':len(rows)},indent=2))
