"""Scalar phase model; never allocates K8048 scientific arrays."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/physics_decisions/hr4e5/e5_1'
G = 8048 * 351 * 301 * 8 * 3
O = 384 * 351 * 301 * 16
assert G == 20406701952 and O == 649119744
META = 2 * 1024**3
SAFETY = 8 * 1024**3
CAP = 300 * 1024**3

# Counts require final code-layout audit. They are conservative phase payloads,
# not a claim that the site has this storage, RAM, quota or GPU capacity.
STAGES = [
    ('initialize', 2, 0, 0, 'independent R PRE and C CURRENT'),
    ('R0_complete', 8, 1, 0, 'R 7G including Batch slots/snapshots/sinks; C CURRENT G'),
    ('pair0_exact', 12, 2, 0, 'R 7G + C 5G'),
    ('R1_ready_before_R0_reclaim', 13, 2, 0, 'pair 12G plus R child G'),
    ('C1_ready_after_R0_reclaim', 7, 2, 0, 'R child G + C parent 5G + C child G'),
    ('fresh_process_resume', 2, 2, 0, 'two independent self-contained active roots'),
    ('pair1_exact', 12, 4, 0, 'second pair full payload plus retained optics'),
    ('R2_ready_before_R1_reclaim', 13, 4, 0, 'second R successor transient'),
    ('failed_handoff_stop', 13, 4, 1, 'conservative additional failed full-G residue; no retries'),
    ('pair1_reclaimed', 2, 4, 0, 'only next active PRE/CURRENT plus bounded evidence'),
    ('final_pair_exact', 8, 6, 0, 'each track PRE POST 2G plus six sinks 2G; no Batch/NEXT'),
    ('final_retention', 2, 6, 0, 'candidate complete CURRENT POST and all final optical'),
]

def main():
    rows = []
    for stage, generations, optics, residue, explanation in STAGES:
        def add(obj, role, shape, dtype, quantity, unit_bytes, gate):
            rows.append(dict(stage=stage, object=obj, role=role, shape=shape, dtype=dtype,
                quantity=quantity, bytes_each=unit_bytes, total_bytes=quantity*unit_bytes,
                unit='bytes', simultaneous=explanation, release_gate=gate,
                evidence='phase lifetime model; actual code-layout qualification in implementation report',
                derivation_level='FORMULA_NOT_HPC_MEASUREMENT'))
        add('slow_generations', 'active_and_transition_payload', '[8048,351,301]x3', 'float64', generations, G,
            'actual exact and independent READY and quiescence and no future dependency')
        add('retained_optical', 'final', '[384,351,301]', 'complex128', optics, O, 'retained')
        add('source_copy_allowance', 'protected_campaign_input_if_copied', '[384,351,301]', 'complex128', 1, O,
            'retained input; zero-cost source copy is not assumed')
        add('failed_handoff_residue', 'unreclaimable_failure', '[8048,351,301]x3', 'float64', residue, G,
            'none; failure stops campaign')
        add('metadata_allowance', 'reports_manifests_containers_logs', 'bounded', 'bytes', 1, META,
            'retained or governed by whitelist; prototype probe has limited extrapolation')
        if stage != 'final_retention':
            add('safety_margin', 'unmaterialized_stop_and_filesystem_headroom', 'bounded', 'bytes', 1, SAFETY,
                'never credited as data reclaimed')
    with (DOC / 'E5_1A_RESOURCE_BUDGET.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    sums = {stage: sum(r['total_bytes'] for r in rows if r['stage'] == stage) for stage, *_ in STAGES}
    result = dict(hard_cap_bytes=CAP, final_cap_bytes=64*1024**3, phase_totals_bytes=sums,
        peak_admission_bytes=max(sums.values()), final_retention_bytes=sums['final_retention'],
        ram_note='host materialization, memmap address space, RSS and VRAM are separate; no large allocation measured',
        qualification='FIXTURE_LAYOUT_ALIGNED; FORMAL_DRIVER_ALIGNMENT_BLOCKED')
    assert max(sums.values()) <= CAP
    assert sums['final_retention'] <= result['final_cap_bytes']
    (ROOT / '.e5_1a_review/evidence/budget_model.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
