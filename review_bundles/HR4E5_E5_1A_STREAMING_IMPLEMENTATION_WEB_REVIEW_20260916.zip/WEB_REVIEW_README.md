# E5-1A web review guide

**Disposition: E5_1A_PARTIAL / BLOCKED_BY_FORMAL_DRIVER_AND_RECOVERY_QUALIFICATION.**
This is a local implementation and bounded CPU evidence delivery. It does not
release E5-1B/C. E5-0 remains closed and its old receipts are unchanged.

Read in order:

1. [Implementation report](reports/E5_1A_IMPLEMENTATION_REPORT_20260916.md):
   implemented interfaces, concrete remaining code gaps and evidence limits.
2. [Executed test results](reports/E5_1A_TEST_RESULTS.json) and
   [qualification matrix](reports/E5_1A_CHANGE_AND_QUALIFICATION_MATRIX.md).
3. [Contract](reports/E5_1A_CONTRACT.json),
   [retention rules](reports/E5_1A_STORAGE_RETENTION_CONTRACT.md), and
   [recomputable budget CSV](reports/E5_1A_RESOURCE_BUDGET.csv).
4. [Baseline diff](patches/base_to_review.diff) and
   [scope audit](evidence/baseline_scope.json); full source/test/dependency copies
   live under source/. Per-object source commit, Git blob and canonical-LF hash
   are in WEB_REVIEW_INDEX.json.

The campaign cap is 322122547200 bytes (300 GiB), shared by R/C, intermediates,
residue and final output. The formula peak is 299676844288 bytes. Default final
retention is 47504725760 bytes against a 68719476736-byte (64 GiB) included cap.
These describe the fixture-aligned lifetime model, not measured K8048 RAM,
VRAM, actual disk allocation or a formally wired production driver.

The N3/K32 test uses an optical test double and the real original CPU hydro and
Streaming lifecycle; separate tests exercise original real optical/state/sink
calls and partial final replay. Actual array comparisons precede deletion.
Distinct subprocess continuation after completed pair1 is compared to an
uninterrupted fixture. This is not cross-node/allocation/power-loss qualification.
Initial failed logs are retained as chronology; final_* logs and the JSON
results identify the accepted latest runs. The manifest prototype performs only
three representative writes and is not a scientific K8048 execution.

Original science, configs/LUTs, old E5-0 documents and S5 entry points are
unchanged. No GPU, Slurm, S5 operation, formal input materialization, B/C run,
merge or force push was performed. Remaining A implementation/recovery gaps
are explicit in the report. B then needs human acceptance, S5 compatibility,
materialized input identity and verified site resource gates.

SHA256SUMS.txt covers all entries except itself. INDEX excludes itself and
SHA256SUMS to avoid circular hashes. The external ZIP hash is reported separately.
