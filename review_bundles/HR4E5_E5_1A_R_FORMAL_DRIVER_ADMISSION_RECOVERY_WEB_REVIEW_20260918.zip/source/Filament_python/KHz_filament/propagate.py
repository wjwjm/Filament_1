from __future__ import annotations
import json
from .device import xp, to_cpu
from .linear import lin_propagator, step_linear, step_linear_bk_nee_factorized
from .ionization import (
    intensity as inten_ion,
    make_Wfunc,
    field_amplitude_from_intensity,
    evolve_rho_time,_ion_input_domain
)
from .nonlinear import kerr_phase_from_deltan, plasma_phase, ib_alpha, apply_nonlinear, shock_intensity, operator_correct_scalar
from .heat import heat_Q_per_z
from .deposition import (
    build_unified_deposition_ledger,
    direct_interval_energy,
    interval_energy_from_fluence_gain,
    interval_energy_from_q,
    q_ib_from_power,
    q_ion_from_power,
    q_raman_from_target_fluence_gain,
)
from .thermalization import ThermalScalarLedger, thermalize_interval
from .slow_state import HR3BScalarLedger, map_post_acoustic_increment
from .linear_full import step_linear_full_factorized, step_linear_full_3d
from .air_dispersion import n_of_omega
from .constants import c0, eps0
from .config import resolve_nonlinear_switches
from .raman import (
    apply_isaacs_raman_operator_step,
    apply_isaacs_complete_eq27_operator_step,
    historical_fr_mixture_response,
    isaacs_raman_stage,
    isaacs_complete_eq27_stage,
    make_raman_kernel,
    precompute_kernel_fft,
    raman_convolve_intensity,
    resolve_raman_rot_params,
)
from .diagnostics import (
    intensity,
    pulse_energy,
    second_moment_radius,
    _fwhm_time_1d,
    parabola_peak,
    _fwhm_diameter_xy_center,
    validate_nonlinear_diagnostics,
)
from .longitudinal import (
    build_deposition_contract,
    build_longitudinal_schedule,
    build_transverse_grid_metadata,
    LongitudinalSchedule,
    DepositionContract,
)

def _linear_phase_per_meter(linear_model, k0, axes, K02_w=None, omega0=None, nee_denom_floor=1e-4):
    """返回线性传播子对应的 |kz| (rad/m) 的 max 值，用于估计 Δφ_linear = kz_max * dz"""
    if linear_model == "paraxial":
        # 相位：exp(i * (-k⊥^2) dz / (2 k0))，幅角/米 = k⊥^2 / (2 k0)
        kz_abs_max = float(xp.max(axes.kperp2) / (2.0 * k0))
    elif linear_model == "bk_nee":
        # Brabec–Krausz NEE 线性项主导的横向衍射相位估计
        if omega0 is None:
            omega0 = float(getattr(axes, "omega0"))
        rel = axes.Omega / float(omega0)
        denom = 1.0 + rel
        denom_abs = xp.maximum(xp.abs(denom), float(nee_denom_floor))
        denom_sign = xp.where(denom >= 0.0, 1.0, -1.0)
        denom = denom_sign * denom_abs
        kz_abs_max = float(xp.max(xp.abs(axes.kperp2[None, ...] / (2.0 * k0 * denom[:, None, None]))))
    else:  # UPPE
        # K02_w = (n(ω) ω / c)^2, kz = sqrt(K02_w - k⊥^2)；取实部的最大值
        if K02_w is None:
            # 退化：用 n0 * ω/c 的中心值做下界估计（更保守些）
            omega_tot = axes.omega0 + axes.Omega
            k0w = (axes.n_w * omega_tot / c0) if hasattr(axes, "n_w") else (k0 * (omega_tot / axes.omega0))
            kz = xp.sqrt(xp.maximum(k0w[:, None, None]**2 - axes.kperp2[None, ...], 0.0))
        else:
            kz = xp.sqrt(xp.maximum(K02_w - axes.kperp2[None, ...], 0.0))
        kz_abs_max = float(xp.max(xp.abs(xp.real(kz))))
    return kz_abs_max


def _combine_raman_operator_diagnostics(parts, *, reference_energy):
    """Combine one or two isolated Raman operator substeps into one z-step record."""
    if not parts:
        return None
    if len(parts) == 1:
        result = dict(parts[0])
        result["operator_substep_count"] = 1
        result["energy_projection_max_scale_deviation"] = abs(
            float(result.get("energy_projection_scale", 1.0)) - 1.0)
        return result
    target_local = sum((part["target_local_fluence_loss_heun"] for part in parts))
    actual_local = sum((part["actual_local_fluence_loss"] for part in parts))
    target_global = sum(float(part["target_global_energy_loss_J"]) for part in parts)
    actual_global = sum(float(part["actual_global_energy_loss_J"]) for part in parts)
    local_residual = float(xp.max(
        xp.abs(actual_local - target_local)
        / xp.maximum(target_local, 1e-300)))
    global_residual = abs(actual_global - target_global) / max(
        target_global, float(reference_energy) * 1e-15, 1e-300)
    return {
        "target_local_fluence_loss_stage1": sum((part["target_local_fluence_loss_stage1"] for part in parts)),
        "target_local_fluence_loss_stage2": sum((part["target_local_fluence_loss_stage2"] for part in parts)),
        "target_local_fluence_loss_heun": target_local,
        "target_local_fluence_loss": target_local,
        "target_global_energy_loss_J": target_global,
        "actual_local_fluence_loss": actual_local,
        "actual_global_energy_loss_J": actual_global,
        "local_closure_residual": local_residual,
        "global_closure_residual": global_residual,
        "rhs_l2_norm_stage1": max(float(part["rhs_l2_norm_stage1"]) for part in parts),
        "rhs_l2_norm_stage2": max(float(part["rhs_l2_norm_stage2"]) for part in parts),
        "IR_max_stage1": max(float(part["IR_max_stage1"]) for part in parts),
        "IR_max_stage2": max(float(part["IR_max_stage2"]) for part in parts),
        "I_R_stage1": parts[-1].get("I_R_stage1"),
        "I_R_stage2": parts[-1].get("I_R_stage2"),
        "convolution_count": sum(int(part["convolution_count"]) for part in parts),
        "operator_substep_count": len(parts),
        "operator_walltime_s": sum(float(part["operator_walltime_s"]) for part in parts),
        "finite": all(bool(part["finite"]) for part in parts),
        "clipping_count": sum(int(part.get("clipping_count", 0)) for part in parts),
        "actual_loss_evaluation": parts[0].get(
            "actual_loss_evaluation", "legacy_fluence_subtraction"),
        "energy_projection_applied": any(
            bool(part.get("energy_projection_applied", False)) for part in parts),
        "energy_projection_iterations": sum(
            int(part.get("energy_projection_iterations", 0)) for part in parts),
        "energy_projection_max_scale_deviation": max(
            abs(float(part.get("energy_projection_scale", 1.0)) - 1.0)
            for part in parts),
        "energy_projection_initial_residual": max(
            float(part.get("energy_projection_initial_residual", 0.0))
            for part in parts),
    }

def _compact_full_raman_diagnostics(diagnostics, *, n_R, k0, dz, y0, x0):
    """Keep the scalar/2-D Eq. (27) audit and release 3-D response payloads.

    A full Raman Strang step returns response volumes for both Heun stages of
    both substeps.  They are useful while forming the per-step accounting, but
    no subsequent propagation operator consumes them.  Keeping those arrays
    alive until the following mixed-precision BK-NEE halfstep can leave too
    little room for its complex128 inverse temporal FFT on a 32 GiB GPU.

    This function evaluates the legacy output scalars from the final raw
    response, then returns a diagnostics dictionary that deliberately contains
    only scalar values.  It does not change the Eq. (27) field update, its
    Strang/Heun order, or its convolution count.
    """
    response = diagnostics.get("I_R_stage1")
    if response is None:
        raw_max = raw_abs_max = raw_peak_max = 0.0
    else:
        raw_max = float(xp.max(response))
        raw_abs_max = float(xp.max(xp.abs(response)))
        raw_peak_max = float(xp.max(response[:, y0, x0]))

    rotational = {
        "IR_max": raw_max,
        "IR_abs_max": raw_abs_max,
        "delta_n_rot_max": float(n_R) * raw_max,
        "delta_n_rot_peak": float(n_R) * raw_peak_max,
        "dphi_rot_max_abs": abs(float(k0) * float(dz) * float(n_R)) * raw_abs_max,
    }
    heavy_payload_keys = {
        "target_local_fluence_loss_stage1",
        "target_local_fluence_loss_stage2",
        "target_local_fluence_loss_heun",
        "target_local_fluence_loss",
        "actual_local_fluence_loss",
        "I_R_stage1",
        "I_R_stage2",
    }
    compact = {key: value for key, value in diagnostics.items()
               if key not in heavy_payload_keys}
    return compact, rotational


def _performance_sync(enabled):
    if enabled and getattr(xp, "__name__", "numpy") == "cupy":
        xp.cuda.Stream.null.synchronize()


# --- 轻量 CPU 侧 FWHM 计算：对 2D map 做圆平均，再找 0.5×峰值的半径 ---
def _fwhm_circular_cpu(map2d_cpu, x_cpu, y_cpu, floor_rel=1e-12, nbins=256):
    import numpy as np
    m = np.asarray(map2d_cpu, dtype=np.float64)
    m = np.nan_to_num(m, nan=0.0, posinf=0.0, neginf=0.0)
    peak = float(m.max())
    if peak <= 0.0:
        return 0.0
    m = np.where(m < floor_rel * peak, 0.0, m)

    X, Y = np.meshgrid(x_cpu, y_cpu, indexing="xy")
    r = np.sqrt(X*X + Y*Y)
    rmax = float(r.max())
    if rmax <= 0:
        return 0.0
    bins = np.linspace(0.0, rmax, nbins+1)
    idx = np.digitize(r.ravel(), bins) - 1
    idx = np.clip(idx, 0, nbins-1)

    sumv = np.bincount(idx, weights=m.ravel(), minlength=nbins)
    cnt  = np.bincount(idx, minlength=nbins)
    prof = np.divide(sumv, np.maximum(cnt, 1), out=np.zeros_like(sumv), where=cnt>0)
    rmid = 0.5*(bins[:-1] + bins[1:])
    # 找到 prof 降到 0.5×peak 的位置做线性插值
    half = 0.5 * float(prof.max())
    below = np.where(prof <= half)[0]
    if below.size == 0:
        return 0.0
    i = int(below[0])
    if i == 0:
        r_half = float(rmid[0])
    else:
        x1, y1 = rmid[i-1], prof[i-1]
        x2, y2 = rmid[i],   prof[i]
        if y2 == y1:
            r_half = float(x2)
        else:
            r_half = float(x1 + (half - y1) * (x2 - x1) / (y2 - y1))
    return 2.0 * r_half  # 直径 FWHM

def propagate_one_pulse(
    E,
    *,
    kperp2,
    k0: float,
    omega0: float,
    dz: float,
    z_max: float,
    n0: float,
    n2: float,
    Ui: float,
    N0: float,
    ion_conf,          # IonizationConfig
    dn_gas=None,
    dt: float,
    axes=None, prop_conf=None, raman_conf=None,
    record_onaxis_rho_time: bool = True,
    record_every_z: int = 1,
    longitudinal_schedule: LongitudinalSchedule | None = None,
    deposition_contract: DepositionContract | None = None,
    thermal_sink=None,
    thermal_slow_state=None,
    hr3b_parameters=None,
    hr3b_sink=None,
    post_commit_hook=None,
):
    """极简稳定版：固定一步只做一次安全缩步（可选近焦加密），标准 Strang 分裂。
       产出统一的 diag 契约（见函数尾部）。"""
    import time
    import numpy as _np
    if post_commit_hook is not None and not callable(post_commit_hook):
        raise TypeError("post_commit_hook must be callable or None")

    # ---------- dtype ----------
    ctype = E.dtype
    rdtype = xp.float32 if ctype == xp.complex64 else xp.float64
    rdtype_np = _np.float32 if ctype == xp.complex64 else _np.float64

    # ---------- 显式、可重放的纵向 schedule ----------
    p = prop_conf
    switches = resolve_nonlinear_switches(p, raman_conf, ion_conf)
    measure_performance = bool(getattr(p, "measure_performance", False))
    dz_base = float(dz)
    use_focus_win = bool(getattr(p, "focus_window_step", False))
    z_center = getattr(p, "focus_center_m", None) or getattr(p, "z_focus_hint", None)
    z_half = float(getattr(p, "focus_halfwidth_m", 0.0))
    dz_focus = float(getattr(p, "dz_focus", dz_base))
    if longitudinal_schedule is None:
        longitudinal_schedule = build_longitudinal_schedule(
            dz_base,
            float(z_max),
            z_start=0.0,
            focus_window_step=use_focus_win,
            focus_center_m=z_center,
            focus_halfwidth_m=z_half,
            dz_focus=dz_focus,
        )
    else:
        if not isinstance(longitudinal_schedule, LongitudinalSchedule):
            raise TypeError("longitudinal_schedule must be a LongitudinalSchedule")
        longitudinal_schedule.validate()
        local_span = longitudinal_schedule.z_edges[-1] - longitudinal_schedule.z_edges[0]
        if not _np.isclose(local_span, float(z_max), rtol=1e-12, atol=1e-12):
            raise ValueError(
                "longitudinal_schedule span must match the local propagation z_max"
            )
    print(
        f"[focus-step] focus_center_m(local)={z_center if z_center is not None else 'None'}, "
        f"focus_halfwidth_m={z_half:.4e}, dz_base={dz_base:.4e}, dz_focus={dz_focus:.4e}"
    )

    # ---------- 索引/几何 ----------
    Ny, Nx = E.shape[-2], E.shape[-1]
    transverse_grid = build_transverse_grid_metadata(axes)
    if deposition_contract is None:
        deposition_contract = build_deposition_contract(
            longitudinal_schedule, transverse_grid=transverse_grid
        )
    elif not isinstance(deposition_contract, DepositionContract):
        raise TypeError("deposition_contract must be a DepositionContract")
    elif deposition_contract.schedule is not longitudinal_schedule:
        raise ValueError("deposition_contract must reference longitudinal_schedule")
    y0, x0 = Ny // 2, Nx // 2
    t_arr = axes.t
    t0_idx = int(xp.argmin(xp.abs(t_arr)))

    save_every = max(1, int(record_every_z))
    save_count = 0
    diag_operator_energy = bool(getattr(p, "diag_operator_energy", False))
    diag_linear_halfstep_energy = bool(getattr(p, "diag_linear_halfstep_energy", False))
    diag_bk_nee_profile = bool(getattr(p, "diag_bk_nee_profile", False))
    if diag_operator_energy and save_every != 1:
        raise ValueError("diag_operator_energy requires record_every_z=1 for step-aligned accounting")
    if diag_linear_halfstep_energy and save_every != 1:
        raise ValueError("diag_linear_halfstep_energy requires record_every_z=1 for step-aligned accounting")

    def _operator_energy(field):
        return float(pulse_energy(intensity(field, n0), dt, axes.dx, axes.dy))


    # ---------- 线性分支 ----------
    linear_model = str(getattr(p, "linear_model", "uppe")).lower()
    use_uppe = (linear_model == "uppe")
    use_bk_nee = (linear_model == "bk_nee")

    if use_uppe:
        Omega = axes.Omega
        omega_tot = omega0 + Omega
        omega_safe = xp.where(xp.abs(omega_tot) < 1e-9 * omega0,
                              xp.sign(omega_tot) * 1e-9 * omega0,
                              omega_tot)
        n_w = n_of_omega(omega_safe,
                         P=getattr(p, "air_P", 101325.0),
                         T=getattr(p, "air_T", 293.15))
        K02_w = (n_w * omega_safe / c0) ** 2
        use_factor = bool(getattr(p, "full_linear_factorize", False))
    if diag_linear_halfstep_energy and not use_bk_nee:
        raise ValueError("diag_linear_halfstep_energy currently audits the production bk_nee path only")
    if diag_bk_nee_profile and not use_bk_nee:
        raise ValueError("diag_bk_nee_profile currently profiles the production bk_nee path only")
    linear_energy_scale = 0.5 * float(eps0) * float(c0) * float(n0) * float(dt) * float(axes.dx) * float(axes.dy)

    def _finalize_linear_halfstep_diagnostic(item):
        if item is None:
            return None
        explicit = sum(float(item[key]) for key in (
            "explicit_boundary_loss_J", "explicit_spectral_filter_loss_J",
            "explicit_crop_loss_J", "explicit_evanescent_loss_J",
            "explicit_other_loss_J",
        ))
        item = dict(item)
        item["field_delta_J"] = float(item["energy_after_J"] - item["energy_before_J"])
        # Sign convention: field_delta < 0 means field loss; explicit losses
        # are positive.  A negative residual is unaccounted field loss.
        item["unaccounted_residual_J"] = float(item["field_delta_J"] + explicit)
        return item

    # ---------- 拉曼（延迟 Kerr + 可选吸收模型） ----------
    # The convolution and the field-feedback switches are intentionally
    # separate: an OFF feedback switch must not erase its raw diagnostic.
    use_raman = switches.compute_raman_convolution
    raman_absorb_on = switches.use_raman_absorption
    raman_absorption_compute = switches.compute_raman_absorption
    absorption_model = "poynting"
    omega_R = Gamma_R = None
    tau_fwhm_cfg = None
    n_rot_frac = 0.99
    R0_mode = "mom"
    R0_fixed = None
    n_R = 0.0
    n2_elec = float(n2)
    fR_ignored_rot_sinexp = False
    r_operator_mode = "legacy_split"

    if use_raman:
        fR_value = getattr(raman_conf, "f_R", None)
        fR = float(fR_value) if fR_value is not None else 0.0
        r_method = str(getattr(raman_conf, "method", "iir")).lower()
        r_chunk = int(getattr(raman_conf, "chunk_pixels", 65536))
        r_model = str(getattr(raman_conf, "model", "rot_sinexp")).lower()
        n_R = float(getattr(raman_conf, "n_R", 2.3e-23))
        r_operator_mode = str(getattr(raman_conf, "operator_mode", "legacy_split")).lower()
        fR_ignored_rot_sinexp = (
            r_model == "rot_sinexp" and r_operator_mode != "historical_fr_mixture"
        )
        if fR_ignored_rot_sinexp:
            print(f"[Raman] model=rot_sinexp uses explicit n_R={n_R:.3e} m^2/W for phase/absorption; f_R={fR:.3g} ignored in phase channel.")
        if (r_method == "fft"):
            h = make_raman_kernel(axes.t, raman_conf)
            H_w = h
        else:
            H_w = None

        # The resolved Phase-2 switch controls whether this raw coefficient is
        # applied; the legacy raman fields only provide compatibility defaults.
        absorption_model = str(getattr(raman_conf, "absorption_model", "poynting")).lower()

        # closed_form 需要的参数（都有默认）
        omega_R, Gamma_R = resolve_raman_rot_params(
            T2=getattr(raman_conf, "T2", None),
            T_R=getattr(raman_conf, "T_R", None),
            omega_R=getattr(raman_conf, "omega_R", None),
            Gamma_R=getattr(raman_conf, "Gamma_R", None),
        )
        tau_fwhm_cfg = getattr(raman_conf, "tau_fwhm", None)
        n_rot_frac = float(getattr(raman_conf, "n_rot_frac", 0.99))
        R0_mode = str(getattr(raman_conf, "R0_mode", "mom")).lower()
        R0_fixed = float(getattr(raman_conf, "R0_fixed_m", 2.0e-4))
    else:
        H_w, fR, r_method, r_chunk = None, 0.0, "iir", 65536
    full_isaacs_complete_mode = bool(
        use_raman and r_operator_mode == "full_isaacs_eq27_complete"
    )
    full_isaacs_rotational_mode = bool(
        use_raman and r_operator_mode == "full_isaacs_eq27"
    )
    full_isaacs_mode = bool(
        full_isaacs_rotational_mode or full_isaacs_complete_mode
    )
    if not use_raman:
        raman_deposition_authoritative = True
        raman_deposition_source = "off"
    elif full_isaacs_mode:
        raman_deposition_authoritative = True
        raman_deposition_source = (
            "eq10_heun_positive_rotational_energy"
            if switches.use_raman_full_operator else "operator_not_applied"
        )
    else:
        raman_deposition_authoritative = False
        raman_deposition_source = "legacy_unavailable"
    complete_operator_enabled = bool(
        full_isaacs_complete_mode and switches.use_raman_full_operator
    )
    historical_fr_mixture_mode = bool(
        use_raman and r_operator_mode == "historical_fr_mixture"
    )
    fR_used_historical_fr_mixture = 0.0
    historical_omega_R = 0.0
    historical_Gamma_R = 0.0
    if historical_fr_mixture_mode:
        # Historical phase kernel parameters are derived from T2/T_R only;
        # the config-level omega_R/Gamma_R remain reserved for absorption.
        fR_used_historical_fr_mixture = float(fR)
        historical_omega_R = 2.0 * _np.pi / float(
            getattr(raman_conf, "T_R", 8.4e-12)
        )
        historical_Gamma_R = 1.0 / float(getattr(raman_conf, "T2", 8.0e-11))
    r_nonlinear_split_order = str(
        getattr(raman_conf, "nonlinear_split_order", "after_other")
    ).lower()

    # ---------- 电离速率 ----------


    ion_off = not switches.use_ionization_solver
    ion_deposition_configured = bool(not ion_off)
    nu_ei_configured = getattr(ion_conf, "nu_ei_const", None)
    ib_deposition_configured = bool(
        not ion_off
        and (
            float(getattr(ion_conf, "sigma_ib", 0.0)) != 0.0
            or (
                nu_ei_configured is not None
                and float(nu_ei_configured) != 0.0
            )
        )
    )
    if ion_off:
        Wfunc, ion_input = None, "none"
    else:
        Wfunc = make_Wfunc(getattr(ion_conf, "model", "none"), ion_conf, omega0, n0)
        ion_input = getattr(Wfunc, "_expects", None)
        if ion_input in ("uses_E", "E"):
            ion_input = "E"
        elif ion_input in ("uses_I", "I"):
            ion_input = "I"
        else:
            ion_input = _ion_input_domain(ion_conf)  # 兜底
    use_ion_op_corr = bool(getattr(ion_conf, "use_ionization_operator_correction", False))
    ion_op_method = str(getattr(ion_conf, "ionization_operator_method", "tdiff")).lower()

    # ---------- 基线能量 ----------
    I0 = intensity(E, n0)
    U0_baseline = float(pulse_energy(I0, dt, axes.dx, axes.dy)) + 1e-30
    energy_print_every = int(getattr(prop_conf, "energy_probe_every", 1))
    if energy_print_every > 0:
        print(f"[U] z={0.000:0.3f} m  U={U0_baseline: .3e} J  Δrel={0.00:.2f}%")

    # ---------- 诊断收集 ----------
    z_axis_list, U_z_list = [], []
    I_max_z_list, rho_max_z_list = [], []
    I_onaxis_max_z_list, I_center_t0_z_list = [], []
    w_mom_z_list, rho_onaxis_max_list = [], []

    E_dep_z_list, E_dep_rot_z_list = [], []  # 电离+IB、拉曼沉积
    E_dep_total_z_list, E_dep_cumulative_z_list = [], []
    # HR-2B canonical interval ledger.  These lists are populated for every
    # schedule interval, independently of sparse legacy z-axis recording.
    E_dep_ion_interval_J_list = []
    E_dep_ib_interval_J_list = []
    E_dep_plasma_interval_J_list = []
    E_dep_ion_interval_direct_J_list = []
    E_dep_ib_interval_direct_J_list = []
    E_dep_plasma_interval_direct_J_list = []
    E_dep_ion_interval_closure_residual_J_list = []
    E_dep_ib_interval_closure_residual_J_list = []
    E_dep_plasma_interval_closure_residual_J_list = []
    E_dep_raman_interval_J_list = []
    E_dep_raman_interval_reduction_reference_J_list = []
    E_dep_raman_interval_operator_J_list = []
    E_dep_raman_interval_closure_residual_J_list = []
    E_dep_raman_operator_energy_residual_J_list = []
    raman_operator_energy_relative_residual_list = []
    raman_actual_local_negative_min_J_m2_list = []
    thermalization_mechanisms = {
        "ion": {"active": ion_deposition_configured, "authoritative": True,
                "source": "positive_photoionization_energy_rate" if ion_deposition_configured else "off"},
        "ib": {"active": ib_deposition_configured, "authoritative": True,
               "source": "alpha_ib_times_intensity" if ib_deposition_configured else "off"},
        "raman": {"active": bool(use_raman), "authoritative": raman_deposition_authoritative,
                  "source": raman_deposition_source},
    }
    thermal_scalar_ledger = ThermalScalarLedger(thermalization_mechanisms)
    hr3b_scalar_ledger = HR3BScalarLedger() if thermal_slow_state is not None else None
    if thermal_slow_state is not None and not isinstance(hr3b_parameters, dict):
        raise ValueError("HR-3B slow state requires explicit mapping parameters")
    U_rel_change_z_list, U_step_change_z_list, E_loss_from_input_z_list = [], [], []
    fwhm_plasma_z_list, fwhm_fluence_z_list, fwhm_time_z_list = [], [], []
    rho_onaxis_time_list = [] if record_onaxis_rho_time else None
    I_onaxis_max_interp_list,alpha_R_mean_z_list,alpha_R_closed_z_list,IR_max_z_list = [],[],[],[]
    delta_n_elec_max_z_list, delta_n_rot_max_z_list = [], []
    delta_n_elec_peak_z_list, delta_n_rot_peak_z_list = [], []
    alpha_R_max_z_list = []
    alpha_ion_raw_max_z_list, alpha_ion_corr_max_z_list = [], []
    alpha_ib_max_z_list, alpha_total_max_z_list, alpha_R_eff_z_list = [], [], []
    delta_n_plasma_min_z_list = []
    dphi_kerr_max_abs_z_list, dphi_elec_max_abs_z_list = [], []
    dphi_rot_max_abs_z_list, dphi_plasma_max_abs_z_list = [], []
    IR_abs_max_z_list = []
    delta_n_elec_applied_max_z_list, delta_n_rot_applied_max_z_list = [], []
    delta_n_plasma_applied_min_z_list = []
    dphi_elec_applied_max_abs_z_list, dphi_rot_applied_max_abs_z_list = [], []
    dphi_plasma_raw_max_abs_z_list, dphi_plasma_applied_max_abs_z_list = [], []
    alpha_ion_applied_max_z_list, alpha_R_raw_max_z_list, alpha_R_applied_max_z_list = [], [], []
    rho_N2_max_z_list, rho_O2_max_z_list = [], []
    rho_N2_at_rho_total_max_z_list, rho_O2_at_rho_total_max_z_list = [], []
    rho_O2_fraction_at_rho_total_max_z_list = []
    dz_used_z_list, adaptive_rejection_count_z_list, safety_mode_trigger_count_z_list = [], [], []
    raman_operator_applied_z_list, raman_rhs_l2_norm_z_list = [], []
    raman_IR_max_raw_z_list, raman_target_loss_step_z_list = [], []
    raman_actual_loss_step_z_list, raman_closure_residual_step_z_list = [], []
    raman_target_loss_cumulative_z_list, raman_actual_loss_cumulative_z_list = [], []
    raman_cumulative_closure_residual_z_list = []
    raman_convolution_count_step_z_list, raman_operator_walltime_step_z_list = [], []
    raman_operator_substep_count_z_list = []
    raman_energy_projection_iterations_z_list = []
    raman_energy_projection_scale_deviation_z_list = []
    raman_energy_projection_initial_residual_z_list = []
    linear_walltime_step_z_list, ionization_walltime_step_z_list = [], []
    total_walltime_step_z_list = []
    gpu_allocated_step_bytes_list, gpu_reserved_step_bytes_list = [], []
    energy_step_start_z_list, energy_after_linear_half1_z_list = [], []
    energy_after_raman_pre_z_list, energy_after_nonraman_z_list = [], []
    energy_after_raman_post_z_list, energy_after_linear_half2_z_list = [], []
    linear_halfstep_1_z_list, linear_halfstep_2_z_list = [], []
    linear_profile_halfstep_1_z_list, linear_profile_halfstep_2_z_list = [], []
    E_dep_cumulative = 0.0
    E_dep_ion_pulse = 0.0
    E_dep_ib_pulse = 0.0
    E_dep_plasma_pulse = 0.0
    E_dep_raman_pulse = 0.0
    E_dep_raman_operator_pulse = 0.0
    E_dep_raman_pulse_closure_residual = 0.0
    E_dep_raman_operator_energy_pulse_residual = 0.0
    raman_target_loss_cumulative = 0.0
    raman_actual_loss_cumulative = 0.0
    U_previous = U0_baseline
    # The current loop has no reject/retry branch; retain live counters so a
    # future controller is observable without inferring state from z_axis.
    adaptive_rejection_count = 0
    safety_mode_trigger_count = 0
    # ---------- 主循环 ----------
    z = 0.0
    # Qacc/Q2D is the legacy slow-heat compatibility path (surface density
    # J/m^2), not the HR-2B thermal truth.  HR-2B keeps only scalar interval
    # ledger values after releasing each temporary q map.
    Qacc = xp.zeros((Ny, Nx), dtype=rdtype)
    Qacc_raman = xp.zeros((Ny, Nx), dtype=rdtype)
    t0 = time.perf_counter()

    def _full_raman_substep(field, step_length):
        stage_kwargs = dict(
            Omega=axes.Omega, dt=dt, omega0=omega0, n0=n0,
            n_R=n_R, omega_R=omega_R, Gamma_R=Gamma_R,
            method=r_method, chunk_pixels=r_chunk,
            iir_sampling=getattr(raman_conf, "iir_sampling", "exact_piecewise_linear"),
        )
        if full_isaacs_complete_mode:
            # In the complete opt-in mode the electronic term is part of the
            # combined field operator.  The independent switch may suppress
            # that component, but it must never fall back to scalar phase.
            stage_kwargs["n2"] = n2_elec if switches.use_electronic_kerr else 0.0
            first_stage = isaacs_complete_eq27_stage(field, **stage_kwargs)
            updated, diagnostics = apply_isaacs_complete_eq27_operator_step(
                field, step_length,
                integrator=getattr(raman_conf, "operator_integrator", "heun"),
                return_diagnostics=True, stage1=first_stage,
                transverse_cell_area=axes.dx * axes.dy, **stage_kwargs,
            )
        else:
            first_stage = isaacs_raman_stage(field, **stage_kwargs)
            updated, diagnostics = apply_isaacs_raman_operator_step(
                field, step_length,
                integrator=getattr(raman_conf, "operator_integrator", "heun"),
                return_diagnostics=True, stage1=first_stage,
                transverse_cell_area=axes.dx * axes.dy, **stage_kwargs,
            )
        diagnostics["operator_walltime_s"] += first_stage["walltime_s"]
        return updated, diagnostics

    for interval_index, interval in enumerate(longitudinal_schedule.intervals):
        _performance_sync(measure_performance)
        step_started = time.perf_counter()
        linear_walltime_step = 0.0
        # The interval was built once by the schedule builder.  Do not make a
        # pulse-dependent/live focus or remainder decision here.
        dz_try = float(interval.dz)

        operator_energy_start = _operator_energy(E) if diag_operator_energy else _np.nan

        _performance_sync(measure_performance)
        linear_started = time.perf_counter()
        linear_halfstep_1_diag = linear_halfstep_2_diag = None
        linear_profile_halfstep_1_diag = linear_profile_halfstep_2_diag = None

        # 线性半步
        if use_uppe:
            if use_factor:
                E = step_linear_full_factorized(E, K02_w, kperp2, dz_try / 2)
            else:
                E = step_linear_full_3d(E, K02_w, kperp2, dz_try / 2)
        elif use_bk_nee:
            linear_result = step_linear_bk_nee_factorized(
                E, Omega=axes.Omega, kperp2=kperp2, k0=k0,
                omega0=omega0, dz=dz_try / 2,
                beta2=float(getattr(p, "nee_beta2", 0.0)),
                denom_floor=float(getattr(p, "nee_denom_floor", 1e-4)),
                precision_strategy=getattr(p, "linear_precision_strategy", "baseline_complex64"),
                return_energy_diagnostics=diag_linear_halfstep_energy,
                energy_scale=linear_energy_scale if diag_linear_halfstep_energy else None,
                return_profile_diagnostics=diag_bk_nee_profile,
            )
            if diag_linear_halfstep_energy and diag_bk_nee_profile:
                E, linear_halfstep_1_diag, linear_profile_halfstep_1_diag = linear_result
            elif diag_linear_halfstep_energy:
                E, linear_halfstep_1_diag = linear_result
            elif diag_bk_nee_profile:
                E, linear_profile_halfstep_1_diag = linear_result
            else:
                E = linear_result
        else:
            prop_xh = xp.sqrt(lin_propagator(kperp2, k0, dz_try, ctype=ctype)).astype(ctype)
            E = step_linear(E, prop_xh)

        # 非线性整步
        _performance_sync(measure_performance)
        if measure_performance:
            linear_walltime_step += time.perf_counter() - linear_started

        operator_energy_after_linear_half1 = _operator_energy(E) if diag_operator_energy else _np.nan

        full_isaacs_on = bool(full_isaacs_mode and switches.use_raman_full_operator)
        raman_diag_parts = []
        full_raman_rotational = None
        if full_isaacs_on and r_nonlinear_split_order in ("before_other", "strang"):
            raman_length = dz_try if r_nonlinear_split_order == "before_other" else 0.5 * dz_try
            E, pre_raman_diag = _full_raman_substep(E, raman_length)
            raman_diag_parts.append(pre_raman_diag)

        operator_energy_after_raman_pre = _operator_energy(E) if diag_operator_energy else _np.nan

        # A strict Strang pre-step changes E before every non-Raman quantity is
        # evaluated, so I, rho, ionization, plasma, and electronic Kerr are live.
        I = inten_ion(E, n0, I_cap=getattr(ion_conf, "I_cap", 1e19))

        # 延迟 Kerr：
        #  - 默认 legacy_split：显式双系数 Δn = n2_elec*I + n_R*I_R
        #  - historical_fr_mixture：pre-April 单总系数混合 Δn = n2*I_nl,
        #    I_nl = (1-f_R)*I + f_R*I_R，仅替换相位算子；吸收路径不变。
        raman_stage_pre = None
        raman_step_diag = None
        if use_raman and not full_isaacs_mode:
            if historical_fr_mixture_mode:
                IR = historical_fr_mixture_response(
                    I, dt=dt,
                    T2=getattr(raman_conf, "T2", None),
                    T_R=getattr(raman_conf, "T_R", None),
                    chunk_pixels=r_chunk,
                )
            else:
                IR = raman_convolve_intensity(
                    I, H_w if r_method == "fft" else None,
                    method=r_method, dt=dt,
                    T2=getattr(raman_conf, "T2", None),
                    T_R=getattr(raman_conf, "T_R", None),
                    omega_R=getattr(raman_conf, "omega_R", None),
                    Gamma_R=getattr(raman_conf, "Gamma_R", None),
                    chunk_pixels=r_chunk,
                    iir_sampling=getattr(raman_conf, "iir_sampling", "legacy_right_hold"),
                )
        else:
            IR = None
        complete_operator_active = bool(
            full_isaacs_complete_mode and full_isaacs_on
        )
        if complete_operator_active:
            # The complete Eq. (27) update below owns both electronic and
            # rotational Kerr terms.  Retain raw electronic diagnostics, but
            # do not feed either component into scalar phase or shock.  The
            # electronic applied trace remains an equivalent ``n2*I`` record;
            # it is not a second scalar phase contribution.
            delta_n_elec = n2_elec * I
            delta_n_rot = xp.zeros_like(I, dtype=rdtype)
            delta_n_elec_applied = (
                delta_n_elec if switches.use_electronic_kerr
                else xp.zeros_like(I, dtype=rdtype)
            )
            delta_n_rot_applied = xp.zeros_like(I, dtype=rdtype)
            delta_n_kerr = xp.zeros_like(I, dtype=rdtype)
        elif historical_fr_mixture_mode and IR is not None:
            delta_n_elec = n2_elec * (1.0 - float(fR)) * I
            delta_n_rot = n2_elec * float(fR) * IR
            delta_n_elec_applied = delta_n_elec if switches.use_electronic_kerr else xp.zeros_like(I, dtype=rdtype)
            delta_n_rot_applied = delta_n_rot if switches.use_raman_phase else xp.zeros_like(I, dtype=rdtype)
            delta_n_kerr = delta_n_elec_applied + delta_n_rot_applied
        else:
            delta_n_elec = n2_elec * I
            delta_n_rot = n_R * IR if (IR is not None) else xp.zeros_like(I, dtype=rdtype)
            delta_n_elec_applied = delta_n_elec if switches.use_electronic_kerr else xp.zeros_like(I, dtype=rdtype)
            delta_n_rot_applied = delta_n_rot if switches.use_raman_phase else xp.zeros_like(I, dtype=rdtype)
            delta_n_kerr = delta_n_elec_applied + delta_n_rot_applied

        if switches.use_self_steepening and not complete_operator_active:
            delta_n_kerr = shock_intensity(
                delta_n_kerr, axes.Omega, omega0, dt=dt,
                method=str(getattr(p, "self_steepening_method", "tdiff")).lower(),
                operator_convention=getattr(raman_conf, "operator_convention", "legacy"),
            )

        # —— 电离/IB 吸收（分开记账）——
        _performance_sync(measure_performance)
        ionization_started = time.perf_counter()
        if ion_off:
            rho = xp.zeros_like(I, dtype=rdtype)
            Wt  = xp.zeros_like(I, dtype=rdtype)
            alpha_ib = xp.zeros_like(I, dtype=rdtype)
            net_density_energy_rate = xp.zeros_like(I, dtype=rdtype)
            photoionization_energy_rate = xp.zeros_like(I, dtype=rdtype)
        else:
            X = field_amplitude_from_intensity(I, n0) if ion_input == "E" else I
            rho_out = evolve_rho_time(
                X, dt, N0, ion_conf.beta_rec, Wfunc,
                quasi_static_time=bool(getattr(ion_conf, "quasi_static_time", False)),
                time_stat=str(getattr(ion_conf, "time_stat", "peak")),
                return_species_terms=True,
                return_species_densities=True,
            )
            if len(rho_out) == 3:
                rho, Wt, species_terms = rho_out
            else:
                rho, Wt = rho_out
                species_terms = {}
            xp.maximum(rho, 0.0, out=rho)
            xp.minimum(rho, N0, out=rho)
            # The legacy field is the energy-weighted net density derivative
            # and may include recombination.  HR-2B deposition and raw
            # ionization absorption use the separate positive photo-creation
            # source below.
            net_density_energy_rate = species_terms.get("drho_dt_u_sum", None)
            photoionization_energy_rate = species_terms.get(
                "photoionization_energy_rate", None
            )
            rho_by_species = species_terms.get("rho_by_species", {})
            if photoionization_energy_rate is None:
                # Compatibility fallback for a non-species return path.
                d_rho_dt = Wt * xp.clip(N0 - rho, 0.0, N0)
                photoionization_energy_rate = Ui * d_rho_dt
            photoionization_energy_rate = xp.asarray(
                photoionization_energy_rate, dtype=rdtype
            )
            photoionization_energy_rate = xp.nan_to_num(
                photoionization_energy_rate,
                nan=0.0,
                posinf=0.0,
                neginf=0.0,
            )
            xp.maximum(photoionization_energy_rate, 0.0, out=photoionization_energy_rate)

        if ion_off:
            rho_by_species = {}

        # Drude IB：优先 nu_ei_const，退回 sigma_ib·rho
        sigma_ib = float(getattr(ion_conf, "sigma_ib", 0.0))
        nu_ei = getattr(ion_conf, "nu_ei_const", None)
        if nu_ei is not None:
            from .constants import e as qe, me, eps0 as _eps0, c0 as _c0
            sigma_ib = (qe * qe / (_eps0 * me * _c0)) * (float(nu_ei) / (float(nu_ei) ** 2 + omega0 ** 2))
        alpha_ib = ib_alpha(rho.astype(rdtype, copy=False), sigma_ib, rdtype=rdtype)
        xp.maximum(alpha_ib, 0.0, out=alpha_ib)

        # 电离吸收 α_ion（只参与传播与热，避免在 Q 中重复计 IB）
        I_floor = 1e-6 * float(getattr(ion_conf, "I_cap", 1e19))
        alpha_ion_raw = photoionization_energy_rate / (I + I_floor)
        if use_ion_op_corr and (not ion_off):
            ion_source_prop = operator_correct_scalar(
                photoionization_energy_rate,
                axes.Omega,
                omega0,
                dt=dt,
                method=ion_op_method,
            )
        else:
            ion_source_prop = photoionization_energy_rate
        ion_source_prop = xp.nan_to_num(ion_source_prop, nan=0.0, posinf=0.0, neginf=0.0)
        alpha_ion = ion_source_prop / (I + I_floor)
        alpha_ion = xp.nan_to_num(alpha_ion, nan=0.0, posinf=0.0, neginf=0.0)
        xp.maximum(alpha_ion, 0.0, out=alpha_ion)
        _performance_sync(measure_performance)
        ionization_walltime_step = (
            time.perf_counter() - ionization_started if measure_performance else 0.0
        )

        # —— 拉曼吸收 —— 两种模型二选一

        alpha_R_eff = 0.0                    # 标量/2D 等效吸收，用于传播
        alpha_R_closed = 0.0                 # 仅 closed_form 模型保留其等效系数
        E_dep_rot_step = 0.0                 # 本 z 步旋转拉曼总沉积能量 [J]
        E_dep_raman_interval = 0.0
        E_dep_raman_interval_reduction_reference = 0.0
        E_dep_raman_operator_interval = 0.0
        E_dep_raman_interval_closure_residual = 0.0
        E_dep_raman_operator_energy_residual = 0.0
        raman_operator_energy_relative_residual = 0.0
        raman_actual_local_negative_min_J_m2 = 0.0
        IR_max = 0.0
        Q_rot_vol = None


        if use_raman and raman_absorption_compute:
            # 文献参数（允许在 config 中覆盖）
            omega_R_use = float(getattr(raman_conf, "omega_R", 1.6e13))
            Gamma_R_use = float(getattr(raman_conf, "Gamma_R", 1.3e13))
            n_R = float(getattr(raman_conf, "n_R", n_R))  # m^2/W

            # 入射能量（用于能量守恒折算）
            U_in = float(pulse_energy(I, dt, axes.dx, axes.dy)) + 1e-30

            scheme = str(getattr(raman_conf, "absorption_model", "conv_deriv")).lower()
            if scheme == "poynting":
                # 兼容名：把 poynting 指到 conv_deriv（同一物理口径）
                scheme = "conv_deriv"

            if scheme in ("conv_deriv", "conv-deriv", "convolution"):
                # ===== (A) 文献式：u_R(τ) = (n_R/c) ∫ Ω(τ') [ I(τ-τ')·∂τ I(τ) ] dτ' =====
                # 计算 I_R = Ω * I（因果卷积）
                IR = raman_convolve_intensity(
                    I, H_w if r_method == "fft" else None,
                    method=r_method, dt=dt,
                    T2=getattr(raman_conf, "T2", None),
                    T_R=getattr(raman_conf, "T_R", None),
                    omega_R=getattr(raman_conf, "omega_R", None),
                    Gamma_R=getattr(raman_conf, "Gamma_R", None),
                    chunk_pixels=r_chunk,
                    iir_sampling=getattr(raman_conf, "iir_sampling", "legacy_right_hold"),
                )
                # ∂I/∂τ（中心差分）
                dIdt = xp.empty_like(I)
                dIdt[1:-1] = (I[2:] - I[:-2]) / (2.0 * dt)
                dIdt[0]    = (I[1] - I[0]) / dt
                dIdt[-1]   = (I[-1] - I[-2]) / dt

                # 经验门限（抑制远尾噪声）
                mask_frac = float(getattr(raman_conf, "abs_mask_frac", 5e-3))
                Ipk = xp.max(I, axis=0) + 1e-30
                mask = I >= (mask_frac * Ipk)[None, ...]

                # 按文献式局域近似：u_R ≈ (n_R/c0) · IR · dI/dt
                w_R = (n_R / c0) * IR * dIdt                     # W/m^3
                w_R = xp.where(mask, w_R, 0.0)

                # 脉内时间积分 → 体能量密度（正值，表示净注入分子转动）
                Q_rot_vol = xp.sum(xp.maximum(w_R, 0.0), axis=0) * dt   # J/m^3
                # 总沉积能量（再乘体元素体积在 z 上的长度）
                E_dep_rot_step = float(xp.sum(Q_rot_vol) * axes.dx * axes.dy * dz_try)

                # 能量守恒折成等效 α_R（用于传播）
                alpha_R_eff = E_dep_rot_step / (U_in * dz_try)
                alpha_R_eff = float(max(0.0, alpha_R_eff))
                # 单步上限（防抽干）
                max_alpha_dz = float(getattr(raman_conf, "max_alpha_dz", 1e-3))
                if alpha_R_eff * dz_try > max_alpha_dz:
                    alpha_R_eff = max_alpha_dz / dz_try

                IR_max = float(IR.max())

            elif scheme in ("alpha_local", "closed_form", "closed-form"):
                # ===== (B) 封闭式：α_R(x,y) = (n_R/(c τ_p)) I0 · bracket（时间常数，逐像素）=====
                # 本地峰值与本地脉宽（用 F/I0 的高斯关系，抗噪&可矢量化）
                I0_xy = xp.max(I, axis=0) + 1e-30                      # W/m^2
                F_xy  = xp.sum(I, axis=0) * dt                          # J/m^2
                C_gauss = _np.sqrt(4.0*_np.log(2.0)/_np.pi)             # ≈0.939
                tau_p_xy = C_gauss * (F_xy / I0_xy)                     # s

                phi_xy = omega_R_use * tau_p_xy
                g_xy   = Gamma_R_use * tau_p_xy
                bracket_xy = 1.0 - xp.exp(-g_xy) * (xp.cos(phi_xy) + (Gamma_R_use/omega_R_use) * xp.sin(phi_xy))

                alpha_map = (n_R / (c0 * tau_p_xy)) * I0_xy * bracket_xy   # 1/m
                alpha_map = xp.clip(alpha_map, 0.0, _np.inf)

                # 单步上限
                max_alpha_dz = float(getattr(raman_conf, "max_alpha_dz", 1e-3))
                alpha_map = xp.minimum(alpha_map, max_alpha_dz / dz_try)

                # 折成本步能量（对面积积分 × dz）
                E_dep_rot_step = float(xp.sum(alpha_map * F_xy) * axes.dx * axes.dy * dz_try)

                # 等效标量 α（用面积-能量加权平均，参与传播）
                # alpha_eff = (∫α F dA)/(∫F dA)
                denomF = float(xp.sum(F_xy) * axes.dx * axes.dy) + 1e-30
                alpha_R_eff = float(xp.sum(alpha_map * F_xy) * axes.dx * axes.dy) / denomF
                alpha_R_closed = alpha_R_eff

            else:
                # 未知方案：关闭吸收，仅延迟 Kerr
                alpha_R_eff = 0.0
                E_dep_rot_step = 0.0

        # Keep raw loss diagnostics even when a corresponding propagation
        # feedback is disabled.  Only *_applied quantities enter alpha_total.
        alpha_ion_applied = alpha_ion if switches.use_ionization_loss else xp.zeros_like(I, dtype=rdtype)
        alpha_R_applied = float(alpha_R_eff) if raman_absorb_on else 0.0
        alpha_total = alpha_ib + alpha_ion_applied + alpha_R_applied

        # 相位
        dphi_k = kerr_phase_from_deltan(delta_n_kerr.astype(rdtype, copy=False), k0, dz_try, rdtype=rdtype)
        dphi_p_raw = plasma_phase(rho.astype(rdtype, copy=False), k0, omega0, dz_try, rdtype=rdtype)
        dphi_p = dphi_p_raw if switches.use_plasma_phase else xp.zeros_like(dphi_p_raw, dtype=rdtype)
        phase  = dphi_k + dphi_p

        # HR-3B consumes exactly one old, interval-centered state slice here.
        # The in-place update occurs only after this interval's q_thermal exists.
        if thermal_slow_state is not None:
            slow_index_slice = thermal_slow_state.read_interval(interval.index)
        else:
            slow_index_slice = dn_gas
        E = apply_nonlinear(E, phase, alpha_total, dz_try, dn_gas=slow_index_slice, k0=k0)
        operator_energy_after_nonraman = _operator_energy(E) if diag_operator_energy else _np.nan
        if full_isaacs_mode:
            if full_isaacs_on:
                if r_nonlinear_split_order in ("after_other", "strang"):
                    raman_length = dz_try if r_nonlinear_split_order == "after_other" else 0.5 * dz_try
                    E, post_raman_diag = _full_raman_substep(E, raman_length)
                    raman_diag_parts.append(post_raman_diag)
                raman_step_diag = _combine_raman_operator_diagnostics(
                    raman_diag_parts, reference_energy=U0_baseline)
                IR = raman_step_diag["I_R_stage1"]
                E_dep_rot_step = float(raman_step_diag["actual_global_energy_loss_J"])
                target_local_fluence_gain = raman_step_diag[
                    "target_local_fluence_loss_heun"
                ]
                q_raman = q_raman_from_target_fluence_gain(
                    target_local_fluence_gain, dz_try
                )
                E_dep_raman_interval = interval_energy_from_q(
                    q_raman, axes.dx, axes.dy, dz_try
                )
                E_dep_raman_interval_reduction_reference = (
                    interval_energy_from_fluence_gain(
                        target_local_fluence_gain, axes.dx, axes.dy
                    )
                )
                E_dep_raman_operator_interval = E_dep_rot_step
                E_dep_raman_interval_closure_residual = (
                    E_dep_raman_interval
                    - E_dep_raman_interval_reduction_reference
                )
                E_dep_raman_operator_energy_residual = (
                    E_dep_raman_interval - E_dep_raman_operator_interval
                )
                raman_operator_energy_relative_residual = abs(
                    E_dep_raman_operator_energy_residual
                ) / max(
                    abs(E_dep_raman_interval),
                    U0_baseline * 1.0e-15,
                    1.0e-300,
                )
                actual_local_fluence_loss = raman_step_diag[
                    "actual_local_fluence_loss"
                ]
                actual_local_fluence_loss_finite = xp.nan_to_num(
                    xp.asarray(actual_local_fluence_loss),
                    nan=0.0, posinf=0.0, neginf=0.0,
                )
                raman_actual_local_negative_min_J_m2 = float(
                    xp.min(xp.minimum(actual_local_fluence_loss_finite, 0.0))
                )
                del target_local_fluence_gain, actual_local_fluence_loss_finite
                E_dep_raman_interval_J_list.append(E_dep_raman_interval)
                E_dep_raman_interval_reduction_reference_J_list.append(
                    E_dep_raman_interval_reduction_reference
                )
                E_dep_raman_interval_operator_J_list.append(
                    E_dep_raman_operator_interval
                )
                E_dep_raman_interval_closure_residual_J_list.append(
                    E_dep_raman_interval_closure_residual
                )
                E_dep_raman_operator_energy_residual_J_list.append(
                    E_dep_raman_operator_energy_residual
                )
                raman_operator_energy_relative_residual_list.append(
                    raman_operator_energy_relative_residual
                )
                raman_actual_local_negative_min_J_m2_list.append(
                    raman_actual_local_negative_min_J_m2
                )
                E_dep_raman_pulse += E_dep_raman_interval
                E_dep_raman_operator_pulse += E_dep_raman_operator_interval
                E_dep_raman_pulse_closure_residual += (
                    E_dep_raman_interval_closure_residual
                )
                E_dep_raman_operator_energy_pulse_residual += (
                    E_dep_raman_operator_energy_residual
                )
                Qacc_raman += xp.maximum(
                    xp.asarray(
                        raman_step_diag["target_local_fluence_loss_heun"],
                        dtype=Qacc_raman.dtype,
                    ),
                    0.0,
                )
                # The complete 3-D Raman response and local closure maps are
                # no longer inputs to the following linear halfstep.  Capture
                # the legacy scalar diagnostics, then drop every reference to
                # those payloads before mixed-precision FFT workspace is
                # requested.  This is a memory-lifetime change only.
                raman_step_diag, full_raman_rotational = _compact_full_raman_diagnostics(
                    raman_step_diag, n_R=n_R, k0=k0, dz=dz_try, y0=y0, x0=x0)
                IR = None
                delta_n_rot = None
                raman_diag_parts.clear()
                pre_raman_diag = None
                post_raman_diag = None
            else:
                stage_kwargs = dict(
                    Omega=axes.Omega, dt=dt, omega0=omega0, n0=n0,
                    n_R=n_R, omega_R=omega_R, Gamma_R=Gamma_R,
                    method=r_method, chunk_pixels=r_chunk,
                    iir_sampling=getattr(raman_conf, "iir_sampling", "exact_piecewise_linear"),
                )
                if full_isaacs_complete_mode:
                    stage_kwargs["n2"] = n2_elec if switches.use_electronic_kerr else 0.0
                    raman_stage_pre = isaacs_complete_eq27_stage(E, **stage_kwargs)
                else:
                    raman_stage_pre = isaacs_raman_stage(E, **stage_kwargs)
                IR = raman_stage_pre["I_R"]
                delta_n_rot = n_R * IR
                raw_target_local = float(dz_try) * raman_stage_pre["q_R_positive"]
                raw_target_global = float(xp.sum(raw_target_local) * axes.dx * axes.dy)
                raman_step_diag = {
                    "target_local_fluence_loss_stage1": raw_target_local,
                    "target_local_fluence_loss_stage2": xp.zeros_like(raw_target_local),
                    "target_local_fluence_loss_heun": raw_target_local,
                    "target_local_fluence_loss": raw_target_local,
                    "target_global_energy_loss_J": raw_target_global,
                    "actual_local_fluence_loss": xp.zeros_like(raw_target_local),
                    "actual_global_energy_loss_J": 0.0,
                    "local_closure_residual": 0.0,
                    "global_closure_residual": 0.0,
                    "rhs_l2_norm_stage1": 0.0,
                    "rhs_l2_norm_stage2": 0.0,
                    "IR_max_stage1": raman_stage_pre["IR_max"],
                    "IR_max_stage2": 0.0,
                    "convolution_count": 1,
                    "operator_walltime_s": raman_stage_pre["walltime_s"],
                    "operator_substep_count": 0,
                    "finite": bool(xp.all(xp.isfinite(IR))),
                }
            raman_target_loss_cumulative += float(raman_step_diag["target_global_energy_loss_J"])
            raman_actual_loss_cumulative += float(raman_step_diag["actual_global_energy_loss_J"])

        if not full_isaacs_on:
            # No authoritative actual field-loss map exists for disabled or
            # legacy Raman paths.  Keep the canonical interval ledger aligned
            # without promoting Q_rot_vol, w_R, or another inferred estimate.
            E_dep_raman_interval_J_list.append(0.0)
            E_dep_raman_interval_reduction_reference_J_list.append(0.0)
            E_dep_raman_interval_operator_J_list.append(0.0)
            E_dep_raman_interval_closure_residual_J_list.append(0.0)
            E_dep_raman_operator_energy_residual_J_list.append(0.0)
            raman_operator_energy_relative_residual_list.append(0.0)
            raman_actual_local_negative_min_J_m2_list.append(0.0)

        # —— HR-2B plasma deposition: mechanism-resolved, one interval only ——
        # q maps are interval-average volume energy densities [J/m^3].  The
        # direct 3-D reductions are kept separately for the Level-1 closure;
        # neither path stores a longitudinal payload.
        operator_energy_after_raman_post = _operator_energy(E) if diag_operator_energy else _np.nan

        q_ion = q_ion_from_power(photoionization_energy_rate, dt)
        ib_power = alpha_ib * I
        q_ib = q_ib_from_power(alpha_ib, I, dt)
        if not full_isaacs_on:
            q_raman = xp.zeros_like(q_ion)
        E_dep_ion_interval = interval_energy_from_q(
            q_ion, axes.dx, axes.dy, dz_try
        )
        E_dep_ib_interval = interval_energy_from_q(
            q_ib, axes.dx, axes.dy, dz_try
        )
        E_dep_plasma_interval = E_dep_ion_interval + E_dep_ib_interval
        E_dep_ion_direct = direct_interval_energy(
            photoionization_energy_rate, dt, axes.dx, axes.dy, dz_try
        )
        E_dep_ib_direct = direct_interval_energy(
            ib_power, dt, axes.dx, axes.dy, dz_try
        )
        E_dep_plasma_direct = E_dep_ion_direct + E_dep_ib_direct
        E_dep_ion_interval_J_list.append(E_dep_ion_interval)
        E_dep_ib_interval_J_list.append(E_dep_ib_interval)
        E_dep_plasma_interval_J_list.append(E_dep_plasma_interval)
        E_dep_ion_interval_direct_J_list.append(E_dep_ion_direct)
        E_dep_ib_interval_direct_J_list.append(E_dep_ib_direct)
        E_dep_plasma_interval_direct_J_list.append(E_dep_plasma_direct)
        E_dep_ion_interval_closure_residual_J_list.append(
            E_dep_ion_interval - E_dep_ion_direct
        )
        E_dep_ib_interval_closure_residual_J_list.append(
            E_dep_ib_interval - E_dep_ib_direct
        )
        E_dep_plasma_interval_closure_residual_J_list.append(
            E_dep_plasma_interval - E_dep_plasma_direct
        )
        E_dep_ion_pulse += E_dep_ion_interval
        E_dep_ib_pulse += E_dep_ib_interval
        E_dep_plasma_pulse += E_dep_plasma_interval

        # HR-3A-R finalizes after Raman and plasma sources are all available.
        # It neither changes the nonlinear split nor feeds the legacy Qacc path.
        thermal_interval = thermalize_interval(
            q_ion=q_ion,
            q_ib=q_ib,
            q_raman=q_raman,
            dz=dz_try,
            dx=axes.dx,
            dy=axes.dy,
            mechanisms=thermalization_mechanisms,
            reference_interval_J={
                "ion": E_dep_ion_interval,
                "ib": E_dep_ib_interval,
                "raman": E_dep_raman_interval,
            },
            x=axes.x,
            y=axes.y,
        )
        thermal_scalar_ledger.append(interval.index, thermal_interval)
        if thermal_sink is not None and thermal_interval["q_thermal"] is not None:
            thermal_sink.record_sample(
                interval.index,
                thermal_interval["q_thermal"],
                components=(
                    {"ion": q_ion, "ib": q_ib, "raman": q_raman}
                    if getattr(thermal_sink, "mode", "production") == "validation" else None
                ),
            )
        if thermal_slow_state is not None:
            if not bool(thermal_interval["authoritative"]):
                raise ValueError("HR-3B requires authoritative HR-3A q_thermal")
            hr3b_interval = map_post_acoustic_increment(
                thermal_interval["q_thermal"],
                source_authoritative=True,
                rho0=hr3b_parameters["rho0"],
                Cv=hr3b_parameters["Cv"],
                T0=hr3b_parameters["T0"],
                n0=hr3b_parameters["n0"],
            )
            state_after = thermal_slow_state.update_interval(
                interval.index, hr3b_interval["delta_n_increment"]
            )
            hr3b_scalar_ledger.append(
                interval.index, hr3b_interval, slow_index_slice, state_after
            )
            if hr3b_sink is not None:
                hr3b_sink.record_sample(
                    interval.index,
                    hr3b_interval["delta_n_increment"],
                    state_after,
                )
            # S2 infrastructure hook: this is the first point at which the
            # interval POST source exists and later optical steps cannot alter
            # it.  Pass an owned host copy only; the hook cannot alias or
            # mutate the optical field, deposition maps, ledger, or CURRENT.
            if post_commit_hook is not None:
                post_commit_hook(
                    interval=interval,
                    state_after=_np.asarray(to_cpu(state_after), dtype=_np.float64).copy(),
                    hr3a_authoritative=bool(thermal_interval["authoritative"]),
                    hr3b_authoritative=bool(hr3b_interval["authoritative"]),
                )
            del hr3b_interval

        # Keep the legacy heat helper as the Q_CAP compatibility guard.  For
        # normal finite production sources this equals q_ion + q_ib exactly;
        # Qacc/Q2D remains the legacy slow-heat path, not thermal truth.
        Qslice = heat_Q_per_z(
            I,
            alpha_ib,
            dt,
            ion_source=photoionization_energy_rate,
            Wt=Wt,
            rho=rho,
            Ui=Ui,
            N0=N0,
        )
        Qacc += xp.asarray(Qslice, dtype=Qacc.dtype) * dz_try
        # Poynting 模式：如需把拉曼也积入慢时间面密度（J/m^2），可把体能量密度乘 dz_try 累起来
        if use_raman and raman_absorb_on and (absorption_model == "poynting") and (Q_rot_vol is not None):
            Qacc += xp.asarray(Q_rot_vol, dtype=Qacc.dtype) * dz_try
        del q_ion, q_ib, q_raman, thermal_interval

        _performance_sync(measure_performance)
        linear_started = time.perf_counter()

        # 第二个线性半步
        if use_uppe:
            if use_factor:
                E = step_linear_full_factorized(E, K02_w, kperp2, dz_try / 2)
            else:
                E = step_linear_full_3d(E, K02_w, kperp2, dz_try / 2)
        elif use_bk_nee:
            linear_result = step_linear_bk_nee_factorized(
                E, Omega=axes.Omega, kperp2=kperp2, k0=k0,
                omega0=omega0, dz=dz_try / 2,
                beta2=float(getattr(p, "nee_beta2", 0.0)),
                denom_floor=float(getattr(p, "nee_denom_floor", 1e-4)),
                precision_strategy=getattr(p, "linear_precision_strategy", "baseline_complex64"),
                return_energy_diagnostics=diag_linear_halfstep_energy,
                energy_scale=linear_energy_scale if diag_linear_halfstep_energy else None,
                return_profile_diagnostics=diag_bk_nee_profile,
            )
            if diag_linear_halfstep_energy and diag_bk_nee_profile:
                E, linear_halfstep_2_diag, linear_profile_halfstep_2_diag = linear_result
            elif diag_linear_halfstep_energy:
                E, linear_halfstep_2_diag = linear_result
            elif diag_bk_nee_profile:
                E, linear_profile_halfstep_2_diag = linear_result
            else:
                E = linear_result
        else:
            prop_xh = xp.sqrt(lin_propagator(kperp2, k0, dz_try, ctype=ctype)).astype(ctype)
            E = step_linear(E, prop_xh)

        # --- 每步诊断 ---
        _performance_sync(measure_performance)
        if measure_performance:
            linear_walltime_step += time.perf_counter() - linear_started
            total_walltime_step = time.perf_counter() - step_started
        else:
            total_walltime_step = 0.0
        gpu_allocated_step = gpu_reserved_step = 0
        if measure_performance and getattr(xp, "__name__", "numpy") == "cupy":
            pool = xp.get_default_memory_pool()
            gpu_allocated_step = int(pool.used_bytes())
            gpu_reserved_step = int(pool.total_bytes())

        operator_energy_after_linear_half2 = _operator_energy(E) if diag_operator_energy else _np.nan

        save_count += 1
        if (
            (save_count % save_every) == 0
            or interval_index == longitudinal_schedule.n_intervals - 1
            or (z + dz_try >= z_max - 1e-16)
        ):
            z_now = float(z + dz_try)
            z_axis_list.append(z_now)

            I_now = intensity(E, n0)
            U_now = float(pulse_energy(I_now, dt, axes.dx, axes.dy))
            U_z_list.append(U_now)
            I_max_z_list.append(float(I_now.max()))
            delta_n_elec_max_z_list.append(float(xp.max(delta_n_elec)))
            delta_n_rot_max_z_list.append(
                full_raman_rotational["delta_n_rot_max"] if full_raman_rotational is not None
                else float(xp.max(delta_n_rot)))
            delta_n_elec_peak_z_list.append(float(xp.max(delta_n_elec[:, y0, x0])))
            delta_n_rot_peak_z_list.append(
                full_raman_rotational["delta_n_rot_peak"] if full_raman_rotational is not None
                else float(xp.max(delta_n_rot[:, y0, x0])))

            # on-axis(t)
            I_onax_t = I_now[:, y0, x0]
            I_onaxis_max_z_list.append(float(I_onax_t.max()))
            I_center_t0_z_list.append(float(I_onax_t[t0_idx]))
            fwhm_time_z_list.append(float(_fwhm_time_1d(I_onax_t, dt)))
            kpk = int(xp.argmax(I_onax_t))
            if 0 < kpk < (I_onax_t.shape[0] - 1):
                I_onaxis_peak_interp = float(parabola_peak(I_onax_t[kpk - 1], I_onax_t[kpk], I_onax_t[kpk + 1]))
            else:
                I_onaxis_peak_interp = float(I_onax_t[kpk])
            I_onaxis_max_interp_list.append(I_onaxis_peak_interp)

            # 二阶矩束腰（对 t 积分后求 2D 矩）
            F2D = (xp.trapezoid if hasattr(xp, "trapezoid") else xp.trapz)(I_now, dx=dt, axis=0)
            w_mom = second_moment_radius(
                I_now, axes.x, axes.y, dt=dt,
                frac_keep=getattr(prop_conf, "mom_frac_keep", 0.999),
                rel_floor=getattr(prop_conf, "mom_rel_floor", 1e-8),
            )
            w_mom_z_list.append(float(w_mom))

            # 电子密度统计
            rho_onax_t = rho[:, y0, x0].astype(rdtype, copy=False)
            rho_onaxis_max_list.append(float(xp.max(rho_onax_t)))
            if record_onaxis_rho_time:
                rho_onaxis_time_list.append(_np.array(to_cpu(rho_onax_t)))

            rho_maxt = xp.max(rho, axis=0)
            rho_max_z_list.append(float(rho_maxt.max()))
            rho_total_flat_index = int(xp.argmax(rho))
            rho_total_max = float(rho.ravel()[rho_total_flat_index])
            rho_n2 = rho_by_species.get("N2")
            rho_o2 = rho_by_species.get("O2")
            rho_n2_max = float(xp.max(rho_n2)) if rho_n2 is not None else 0.0
            rho_o2_max = float(xp.max(rho_o2)) if rho_o2 is not None else 0.0
            rho_n2_at_total_max = float(rho_n2.ravel()[rho_total_flat_index]) if rho_n2 is not None else 0.0
            rho_o2_at_total_max = float(rho_o2.ravel()[rho_total_flat_index]) if rho_o2 is not None else 0.0
            rho_N2_max_z_list.append(rho_n2_max)
            rho_O2_max_z_list.append(rho_o2_max)
            rho_N2_at_rho_total_max_z_list.append(rho_n2_at_total_max)
            rho_O2_at_rho_total_max_z_list.append(rho_o2_at_total_max)
            rho_O2_fraction_at_rho_total_max_z_list.append(rho_o2_at_total_max / max(rho_total_max, 1e-30))
            dz_used_z_list.append(float(dz_try))
            adaptive_rejection_count_z_list.append(int(adaptive_rejection_count))
            safety_mode_trigger_count_z_list.append(int(safety_mode_trigger_count))

            # 步内沉积能量（J）
            E_dep = float(xp.sum(Qslice) * axes.dx * axes.dy * dz_try)  # 电离+IB
            E_dep_z_list.append(E_dep)
            E_dep_total = E_dep + float(E_dep_rot_step)
            E_dep_cumulative += E_dep_total
            E_dep_total_z_list.append(E_dep_total)
            E_dep_cumulative_z_list.append(E_dep_cumulative)
            U_rel_change_z_list.append((U_now - U0_baseline) / U0_baseline)
            U_step_change_z_list.append(U_now - U_previous)
            E_loss_from_input_z_list.append(U0_baseline - U_now)
            U_previous = U_now
            energy_step_start_z_list.append(operator_energy_start)
            energy_after_linear_half1_z_list.append(operator_energy_after_linear_half1)
            energy_after_raman_pre_z_list.append(operator_energy_after_raman_pre)
            energy_after_nonraman_z_list.append(operator_energy_after_nonraman)
            energy_after_raman_post_z_list.append(operator_energy_after_raman_post)
            energy_after_linear_half2_z_list.append(operator_energy_after_linear_half2)
            if diag_linear_halfstep_energy:
                linear_halfstep_1_z_list.append(_finalize_linear_halfstep_diagnostic(linear_halfstep_1_diag))
                linear_halfstep_2_z_list.append(_finalize_linear_halfstep_diagnostic(linear_halfstep_2_diag))
            if diag_bk_nee_profile:
                linear_profile_halfstep_1_z_list.append(linear_profile_halfstep_1_diag)
                linear_profile_halfstep_2_z_list.append(linear_profile_halfstep_2_diag)
            alpha_ion_raw_max_z_list.append(float(xp.max(xp.maximum(alpha_ion_raw, 0.0))))
            alpha_ion_corr_max_z_list.append(float(xp.max(alpha_ion)))
            alpha_ion_applied_max_z_list.append(float(xp.max(alpha_ion_applied)))
            alpha_ib_max_z_list.append(float(xp.max(alpha_ib)))
            alpha_total_max_z_list.append(float(xp.max(alpha_total)))
            # 拉曼沉积
            if full_isaacs_mode:
                E_dep_rot = float(E_dep_rot_step)
                alphaR_raw = 0.0
            elif use_raman and raman_absorption_compute:
                E_dep_rot = E_dep_rot_step
                alphaR_raw = float(alpha_R_eff)
            else:
                E_dep_rot = alphaR_raw = 0.0
            alphaR_applied = float(alpha_R_applied)
            alphaR_max = alphaR_applied
            alphaR_mean = alphaR_applied

            E_dep_rot_z_list.append(E_dep_rot)
            alpha_R_max_z_list.append(alphaR_max)
            alpha_R_mean_z_list.append(alphaR_mean)
            alpha_R_eff_z_list.append(alphaR_applied)
            alpha_R_closed_z_list.append(float(alpha_R_closed) if raman_absorb_on else 0.0)
            alpha_R_raw_max_z_list.append(alphaR_raw)
            alpha_R_applied_max_z_list.append(alphaR_applied)
            IR_max_z_list.append(
                full_raman_rotational["IR_max"] if full_raman_rotational is not None
                else (float(xp.max(IR)) if IR is not None else 0.0))
            IR_abs_max_z_list.append(
                full_raman_rotational["IR_abs_max"] if full_raman_rotational is not None
                else (float(xp.max(xp.abs(IR))) if IR is not None else 0.0))
            if raman_step_diag is None:
                raman_step_diag = {
                    "target_global_energy_loss_J": 0.0,
                    "actual_global_energy_loss_J": 0.0,
                    "global_closure_residual": 0.0,
                    "rhs_l2_norm_stage1": 0.0,
                    "rhs_l2_norm_stage2": 0.0,
                    "IR_max_stage1": float(xp.max(xp.abs(IR))) if IR is not None else 0.0,
                    "convolution_count": 0,
                    "operator_walltime_s": 0.0,
                }
            cumulative_closure = 0.0 if not full_isaacs_on else abs(
                raman_actual_loss_cumulative - raman_target_loss_cumulative
            ) / max(raman_target_loss_cumulative, U0_baseline * 1e-15, 1e-300)
            raman_operator_applied_z_list.append(bool(full_isaacs_on))
            raman_rhs_l2_norm_z_list.append(max(
                float(raman_step_diag["rhs_l2_norm_stage1"]),
                float(raman_step_diag["rhs_l2_norm_stage2"])))
            raman_IR_max_raw_z_list.append(float(raman_step_diag["IR_max_stage1"]))
            raman_target_loss_step_z_list.append(float(raman_step_diag["target_global_energy_loss_J"]))
            raman_actual_loss_step_z_list.append(float(raman_step_diag["actual_global_energy_loss_J"]))
            raman_closure_residual_step_z_list.append(float(raman_step_diag["global_closure_residual"]))
            raman_target_loss_cumulative_z_list.append(float(raman_target_loss_cumulative))
            raman_actual_loss_cumulative_z_list.append(float(raman_actual_loss_cumulative))
            raman_cumulative_closure_residual_z_list.append(float(cumulative_closure))
            raman_convolution_count_step_z_list.append(int(raman_step_diag["convolution_count"]))
            raman_operator_substep_count_z_list.append(int(raman_step_diag.get("operator_substep_count", 0)))
            raman_operator_walltime_step_z_list.append(float(raman_step_diag["operator_walltime_s"]))
            raman_energy_projection_iterations_z_list.append(int(
                raman_step_diag.get("energy_projection_iterations", 0)))
            raman_energy_projection_scale_deviation_z_list.append(float(
                raman_step_diag.get("energy_projection_max_scale_deviation", 0.0)))
            raman_energy_projection_initial_residual_z_list.append(float(
                raman_step_diag.get("energy_projection_initial_residual", 0.0)))
            linear_walltime_step_z_list.append(float(linear_walltime_step))
            ionization_walltime_step_z_list.append(float(ionization_walltime_step))
            total_walltime_step_z_list.append(float(total_walltime_step))
            gpu_allocated_step_bytes_list.append(int(gpu_allocated_step))
            gpu_reserved_step_bytes_list.append(int(gpu_reserved_step))
            delta_n_plasma_min_z_list.append(float(xp.min(dphi_p_raw)) / (float(k0) * dz_try))
            delta_n_elec_applied_max_z_list.append(float(xp.max(delta_n_elec_applied)))
            delta_n_rot_applied_max_z_list.append(float(xp.max(delta_n_rot_applied)))
            delta_n_plasma_applied_min_z_list.append(float(xp.min(dphi_p)) / (float(k0) * dz_try))
            dphi_kerr_max_abs_z_list.append(float(xp.max(xp.abs(dphi_k))))
            dphi_elec_max_abs_z_list.append(float(xp.max(xp.abs(float(k0) * delta_n_elec * dz_try))))
            dphi_rot_max_abs_z_list.append(
                full_raman_rotational["dphi_rot_max_abs"] if full_raman_rotational is not None
                else float(xp.max(xp.abs(float(k0) * delta_n_rot * dz_try))))
            dphi_elec_applied_max_abs_z_list.append(float(xp.max(xp.abs(float(k0) * delta_n_elec_applied * dz_try))))
            dphi_rot_applied_max_abs_z_list.append(float(xp.max(xp.abs(float(k0) * delta_n_rot_applied * dz_try))))
            dphi_plasma_raw_max_abs_z_list.append(float(xp.max(xp.abs(dphi_p_raw))))
            dphi_plasma_applied_max_abs_z_list.append(float(xp.max(xp.abs(dphi_p))))
            dphi_plasma_max_abs_z_list.append(float(xp.max(xp.abs(dphi_p))))

            # FWHM：等离子体通道 与 能量密度
            fwhm_plasma = _fwhm_diameter_xy_center(rho_maxt, axes, x0, y0)
            fwhm_flu    = _fwhm_diameter_xy_center(F2D,      axes, x0, y0)
            fwhm_plasma_z_list.append(float(fwhm_plasma))
            fwhm_fluence_z_list.append(float(fwhm_flu))

            # 能量哨兵打印

            if energy_print_every > 0:
                steps_done = len(z_axis_list)
                if (steps_done % energy_print_every == 0) or (z_now >= z_max - 1e-16):
                    drel = 100.0 * (U_now - U0_baseline) / U0_baseline
                    print(f"[U] z={z_now:0.3f} m  U={U_now: .3e} J  Δrel={drel:.2f}%")
                    if bool(getattr(p, "diag_extra", False)):
                        print(
                            f"[NL] z={z_now:0.3f} m  Ipk={I_max_z_list[-1]:.3e} W/m^2  "
                            f"Δn_e={delta_n_elec_max_z_list[-1]:.3e}  Δn_R={delta_n_rot_max_z_list[-1]:.3e}  "
                            f"IR={IR_abs_max_z_list[-1]:.3e} W/m^2  "
                            f"Δn_p,min={delta_n_plasma_min_z_list[-1]:.3e}  "
                            f"|φ_K|={dphi_kerr_max_abs_z_list[-1]:.3e} rad  "
                            f"|φ_p|={dphi_plasma_max_abs_z_list[-1]:.3e} rad  "
                            f"α_ion(raw/appl)={alpha_ion_corr_max_z_list[-1]:.3e}/{alpha_ion_applied_max_z_list[-1]:.3e}  "
                            f"α_IB={alpha_ib_max_z_list[-1]:.3e}  α_R(raw/appl)={alpha_R_raw_max_z_list[-1]:.3e}/{alpha_R_applied_max_z_list[-1]:.3e} m^-1  "
                            f"Edep={E_dep_total_z_list[-1]:.3e} J"
                        )
                    # --- monitor PPT_i cap-hit (after evolve_rho_time) ---
                    W_cap_used = float(getattr(ion_conf, "W_cap", 0.0))
                    if W_cap_used > 0.0:
                        thr = 0.999 * W_cap_used
                        hits = 0
                        total = 0
                        # 可选抽样以进一步降开销：t_stride=1 表示不抽样
                        t_stride = 1
                        for it in range(0, Wt.shape[0], t_stride):
                            frm = Wt[it]  # [Ny,Nx]，此处只会临时分配一个小掩码
                            hits += int(xp.count_nonzero(frm >= thr))
                            total += frm.size
                        hit_frac = hits / max(1, total)
                        print(f"[z={z:.3f} m] PPT_i cap-hit = {hit_frac * 100:.3f}% (cap={W_cap_used:.2e})")

        # 前进 z & 进度
        z += dz_try
        pe = int(getattr(p, "progress_every_z", 0) or 0)
        if pe and ((len(z_axis_list) % pe) == 0 or z >= z_max - 1e-16):
            frac = z / z_max
            elapsed = time.perf_counter() - t0
            eta = elapsed / max(frac, 1e-9) * (1.0 - frac)
            print(f"[z] {z:.3f}/{z_max:.3f} m ({frac*100:6.2f}%)  elapsed {elapsed:6.1f}s  ETA {eta:6.1f}s")

    # ---------- HR-2D unified scalar ledger ----------
    # This consumes only the canonical interval scalars accumulated above.
    # It deliberately does not consult sparse legacy E_dep*_z diagnostics,
    # legacy Raman estimates, or the field-loss diagnostic as a deposition
    # source.
    unified_deposition = build_unified_deposition_ledger(
        ion_interval_J=E_dep_ion_interval_J_list,
        ib_interval_J=E_dep_ib_interval_J_list,
        raman_interval_J=E_dep_raman_interval_J_list,
        ion_interval_reference_J=E_dep_ion_interval_direct_J_list,
        ib_interval_reference_J=E_dep_ib_interval_direct_J_list,
        raman_interval_reference_J=E_dep_raman_interval_reduction_reference_J_list,
        ion_pulse_J=E_dep_ion_pulse,
        ib_pulse_J=E_dep_ib_pulse,
        raman_pulse_J=E_dep_raman_pulse,
        ion_configured=ion_deposition_configured,
        ib_configured=ib_deposition_configured,
        raman_configured=bool(use_raman),
        raman_authoritative=raman_deposition_authoritative,
        raman_source=raman_deposition_source,
        ionization_feedback_enabled=bool(switches.use_ionization_loss),
        raman_feedback_enabled=bool(switches.use_raman_full_operator),
        field_in_J=U0_baseline,
        field_out_J=(U_z_list[-1] if U_z_list else _np.nan),
        raman_operator_relative_residuals=(
            raman_operator_energy_relative_residual_list
        ),
        raman_operator_cumulative_relative_residual=(
            abs(E_dep_raman_operator_pulse - E_dep_raman_pulse)
            / max(abs(E_dep_raman_pulse), U0_baseline * 1.0e-15, 1.0e-300)
            if full_isaacs_on else None
        ),
    )
    thermalization = thermal_scalar_ledger.as_dict()
    thermalization["mechanisms"] = thermalization_mechanisms
    thermal_archive = (
        thermal_sink.finalize()
        if thermal_sink is not None else {
            "thermal_map_archive_schema": "khz_filament.hr3a.qthermal_samples.v1",
            "thermal_map_archive_filename": "", "thermal_map_archive_dtype": "",
            "thermal_map_archive_shape": (0, Ny, Nx), "thermal_map_archive_complete": False,
            "thermal_map_archive_enabled": False, "thermal_map_archive_mode": "production",
            "thermal_map_archive_disabled_reason": "no_sink",
        }
    )
    hr3b_archive = (
        hr3b_sink.finalize()
        if hr3b_sink is not None else {
            "hr3b_map_archive_schema": "khz_filament.hr3b.sparse_maps.v1",
            "hr3b_increment_archive_filename": "",
            "hr3b_state_after_archive_filename": "",
            "hr3b_map_archive_dtype": "",
            "hr3b_map_archive_shape": (0, Ny, Nx),
            "hr3b_map_archive_complete": False,
            "hr3b_map_archive_enabled": False,
            "hr3b_map_archive_disabled_reason": "no_sink",
        }
    )
    hr3b_ledger = hr3b_scalar_ledger.as_dict() if hr3b_scalar_ledger is not None else None
    hr3b_state_metadata = thermal_slow_state.metadata() if thermal_slow_state is not None else None
    thermal_sample_plan = getattr(thermal_sink, "plan", None)
    if thermal_sample_plan is None:
        thermal_sample_plan_metadata = {
            "target_z_m": _np.empty(0, dtype=_np.float64), "interval_index": _np.empty(0, dtype=_np.int64),
            "z_left_m": _np.empty(0, dtype=_np.float64), "z_right_m": _np.empty(0, dtype=_np.float64),
            "z_mid_m": _np.empty(0, dtype=_np.float64), "snap_error_m": _np.empty(0, dtype=_np.float64),
            "region": _np.empty(0, dtype="U32"), "reason": _np.empty(0, dtype="U128"),
        }
    else:
        thermal_sample_plan_metadata = {
            "target_z_m": thermal_sample_plan.target_z_m, "interval_index": thermal_sample_plan.interval_index,
            "z_left_m": thermal_sample_plan.z_left_m, "z_right_m": thermal_sample_plan.z_right_m,
            "z_mid_m": thermal_sample_plan.z_mid_m, "snap_error_m": thermal_sample_plan.snap_error_m,
            "region": thermal_sample_plan.region, "reason": thermal_sample_plan.reason,
        }
    thermalization_mechanism_status_json = json.dumps(
        thermalization["mechanisms"], sort_keys=True, separators=(",", ":")
    )
    mechanism_status_json = json.dumps(
        unified_deposition["mechanisms"], sort_keys=True, separators=(",", ":")
    )

    # ---------- 打包 ----------
    diag = {
        # Canonical schedule metadata is complete and absolute.  Legacy
        # z_axis/dz_used_z below intentionally retain their local/sparse
        # propagation semantics.
        "longitudinal_schedule_schema": _np.asarray(
            "khz_filament.longitudinal_schedule.v1"
        ),
        "z_edges": _np.asarray(longitudinal_schedule.z_edges, dtype=_np.float64),
        "dz_intervals": _np.asarray(longitudinal_schedule.dz_intervals, dtype=_np.float64),
        "n_intervals": _np.int64(longitudinal_schedule.n_intervals),
        "longitudinal_z_start": float(longitudinal_schedule.z_start),
        "longitudinal_z_end": float(longitudinal_schedule.z_end),
        "deposition_contract_schema": _np.asarray(
            "khz_filament.deposition_contract.v1"
        ),
        "deposition_channels": _np.asarray(
            deposition_contract.channels, dtype="U64"
        ),
        "deposition_channel_names": _np.asarray(
            deposition_contract.channels, dtype="U64"
        ),
        "deposition_channel_count": _np.int64(len(deposition_contract.channels)),
        "deposition_value_name": _np.asarray(deposition_contract.value_name),
        "deposition_value_unit": _np.asarray(deposition_contract.value_unit),
        "deposition_representation": _np.asarray(deposition_contract.representation),
        "deposition_payload_allocated": _np.bool_(deposition_contract.payload_allocated),
        "deposition_q_shape": _np.asarray(deposition_contract.q_shape, dtype=_np.int64),
        "deposition_n_intervals": _np.int64(deposition_contract.n_intervals),
        "thermal_grid_matches_optical": _np.bool_(
            deposition_contract.transverse_grid.same_grid
        ),
        "transverse_remapping": _np.asarray(
            "none" if deposition_contract.transverse_grid.same_grid else "external"
        ),
        "z_axis":                   _np.asarray(z_axis_list,              dtype=rdtype_np),
        "U_z":                      _np.asarray(U_z_list,                 dtype=rdtype_np),
        "I_max_z":                  _np.asarray(I_max_z_list,             dtype=rdtype_np),
        "I_onaxis_max_z":           _np.asarray(I_onaxis_max_z_list,      dtype=rdtype_np),
        "I_center_t0_z":            _np.asarray(I_center_t0_z_list,       dtype=rdtype_np),
        "w_mom_z":                  _np.asarray(w_mom_z_list,             dtype=rdtype_np),
        "rho_max_z":                _np.asarray(rho_max_z_list,           dtype=rdtype_np),
        "rho_onaxis_max_z":         _np.asarray(rho_onaxis_max_list,      dtype=rdtype_np),
        "E_dep_z":                  _np.asarray(E_dep_z_list,             dtype=rdtype_np),   # 电离+IB
        "E_dep_total_z":            _np.asarray(E_dep_total_z_list,       dtype=rdtype_np),
        "E_dep_cumulative_z":       _np.asarray(E_dep_cumulative_z_list,  dtype=rdtype_np),
        # HR-2B authoritative plasma deposition ledger.  These arrays are
        # canonical-interval aligned and intentionally independent of the
        # legacy sparse z_axis records above.
        "E_dep_ion_interval_J": _np.asarray(
            E_dep_ion_interval_J_list, dtype=_np.float64
        ),
        "E_dep_ib_interval_J": _np.asarray(
            E_dep_ib_interval_J_list, dtype=_np.float64
        ),
        "E_dep_plasma_interval_J": _np.asarray(
            E_dep_plasma_interval_J_list, dtype=_np.float64
        ),
        "E_dep_ion_interval_direct_J": _np.asarray(
            E_dep_ion_interval_direct_J_list, dtype=_np.float64
        ),
        "E_dep_ib_interval_direct_J": _np.asarray(
            E_dep_ib_interval_direct_J_list, dtype=_np.float64
        ),
        "E_dep_plasma_interval_direct_J": _np.asarray(
            E_dep_plasma_interval_direct_J_list, dtype=_np.float64
        ),
        "E_dep_ion_interval_closure_residual_J": _np.asarray(
            E_dep_ion_interval_closure_residual_J_list, dtype=_np.float64
        ),
        "E_dep_ib_interval_closure_residual_J": _np.asarray(
            E_dep_ib_interval_closure_residual_J_list, dtype=_np.float64
        ),
        "E_dep_plasma_interval_closure_residual_J": _np.asarray(
            E_dep_plasma_interval_closure_residual_J_list, dtype=_np.float64
        ),
        "E_dep_ion_pulse_J": float(E_dep_ion_pulse),
        "E_dep_ib_pulse_J": float(E_dep_ib_pulse),
        "E_dep_plasma_pulse_J": float(E_dep_plasma_pulse),
        # HR-2C-R authoritative Raman deposition is the positive Eq.10/Heun
        # rotational medium-gain source.  The signed field-loss scalar remains
        # a separate operator-energy diagnostic; no q/map stack is retained.
        "E_dep_raman_interval_J": _np.asarray(
            E_dep_raman_interval_J_list, dtype=_np.float64
        ),
        "E_dep_raman_interval_reduction_reference_J": _np.asarray(
            E_dep_raman_interval_reduction_reference_J_list, dtype=_np.float64
        ),
        "E_dep_raman_interval_operator_J": _np.asarray(
            E_dep_raman_interval_operator_J_list, dtype=_np.float64
        ),
        "E_dep_raman_interval_closure_residual_J": _np.asarray(
            E_dep_raman_interval_closure_residual_J_list, dtype=_np.float64
        ),
        "E_dep_raman_operator_energy_residual_J": _np.asarray(
            E_dep_raman_operator_energy_residual_J_list, dtype=_np.float64
        ),
        "raman_operator_energy_closure_relative_interval": _np.asarray(
            raman_operator_energy_relative_residual_list, dtype=_np.float64
        ),
        "E_dep_raman_pulse_J": float(E_dep_raman_pulse),
        "E_dep_raman_operator_pulse_J": float(E_dep_raman_operator_pulse),
        "E_dep_raman_pulse_closure_residual_J": float(
            E_dep_raman_pulse_closure_residual
        ),
        "E_dep_raman_operator_energy_pulse_residual_J": float(
            E_dep_raman_operator_energy_pulse_residual
        ),
        # HR-2D unified deposition bookkeeping.  The mechanism-resolved
        # interval arrays above remain the canonical source; the total is
        # populated only when every active mechanism is authoritative.
        "unified_deposition_ledger_schema": _np.asarray(
            "khz_filament.unified_deposition_ledger.v1"
        ),
        "deposition_mechanism_status_json": _np.asarray(mechanism_status_json),
        "deposition_ion_configured": bool(
            unified_deposition["mechanisms"]["ion"]["configured"]
        ),
        "deposition_ion_active": bool(
            unified_deposition["mechanisms"]["ion"]["active"]
        ),
        "deposition_ion_authoritative": bool(
            unified_deposition["mechanisms"]["ion"]["authoritative"]
        ),
        "deposition_ion_source": _np.asarray(
            unified_deposition["mechanisms"]["ion"]["source"]
        ),
        "deposition_ion_feedback_applied": bool(
            unified_deposition["mechanisms"]["ion"]["feedback_applied"]
        ),
        "deposition_ib_configured": bool(
            unified_deposition["mechanisms"]["ib"]["configured"]
        ),
        "deposition_ib_active": bool(
            unified_deposition["mechanisms"]["ib"]["active"]
        ),
        "deposition_ib_authoritative": bool(
            unified_deposition["mechanisms"]["ib"]["authoritative"]
        ),
        "deposition_ib_source": _np.asarray(
            unified_deposition["mechanisms"]["ib"]["source"]
        ),
        "deposition_raman_configured": bool(
            unified_deposition["mechanisms"]["raman"]["configured"]
        ),
        "deposition_raman_active": bool(
            unified_deposition["mechanisms"]["raman"]["active"]
        ),
        "deposition_raman_authoritative": bool(
            unified_deposition["mechanisms"]["raman"]["authoritative"]
        ),
        "deposition_raman_source": _np.asarray(
            unified_deposition["mechanisms"]["raman"]["source"]
        ),
        "deposition_raman_feedback_applied": bool(
            unified_deposition["mechanisms"]["raman"]["feedback_applied"]
        ),
        "deposition_ion_level1_closure_status": _np.asarray(
            unified_deposition["level1"]["ion"]
        ),
        "deposition_ib_level1_closure_status": _np.asarray(
            unified_deposition["level1"]["ib"]
        ),
        "deposition_raman_level1_closure_status": _np.asarray(
            unified_deposition["level1"]["raman"]
        ),
        "deposition_raman_deposition_reduction_closure_status": _np.asarray(
            unified_deposition["level1"]["raman"]
        ),
        "deposition_raman_operator_energy_closure_status": _np.asarray(
            unified_deposition["raman_operator_energy_closure_status"]
        ),
        "raman_operator_energy_step_p99": float(
            unified_deposition["raman_operator_energy_step_p99"]
        ),
        "raman_operator_energy_cumulative_relative": float(
            unified_deposition["raman_operator_energy_cumulative_relative"]
        ),
        "raman_operator_energy_step_p99_tolerance": float(
            unified_deposition["raman_operator_energy_step_p99_tolerance"]
        ),
        "raman_operator_energy_cumulative_tolerance": float(
            unified_deposition["raman_operator_energy_cumulative_tolerance"]
        ),
        "deposition_level1_all_available_mechanism_closure_pass": bool(
            unified_deposition["level1_all_available_pass"]
        ),
        "deposition_ion_level2_closure_status": _np.asarray(
            unified_deposition["level2"]["ion"]
        ),
        "deposition_ib_level2_closure_status": _np.asarray(
            unified_deposition["level2"]["ib"]
        ),
        "deposition_raman_level2_closure_status": _np.asarray(
            unified_deposition["level2"]["raman"]
        ),
        "deposition_level2_all_available_mechanism_closure_pass": bool(
            unified_deposition["level2_all_available_pass"]
        ),
        "total_deposition_authoritative": bool(
            unified_deposition["total_authoritative"]
        ),
        "total_deposition_unavailable_reason": _np.asarray(
            unified_deposition["total_unavailable_reason"]
        ),
        "E_dep_total_interval_J": _np.asarray(
            unified_deposition["total_interval_J"], dtype=_np.float64
        ),
        "E_dep_total_pulse_J": float(unified_deposition["total_pulse_J"]),
        "E_dep_total_level2_closure_status": _np.asarray(
            unified_deposition["total_level2_status"]
        ),
        "deposition_closure_relative_tolerance": float(
            unified_deposition["closure_relative_tolerance"]
        ),
        # Level-3 is a signed optical-field bookkeeping diagnostic only.
        # Positive residual means field loss not covered by authoritative
        # deposition; it is never promoted to a deposition or heat source.
        "E_field_in_J": float(unified_deposition["field_in_J"]),
        "E_field_out_J": float(unified_deposition["field_out_J"]),
        "E_field_loss_J": float(unified_deposition["field_loss_J"]),
        "E_dep_accounted_authoritative_J": float(
            unified_deposition["accounted_authoritative_J"]
        ),
        "E_field_energy_bookkeeping_residual_J": float(
            unified_deposition["field_residual_J"]
        ),
        "E_field_energy_bookkeeping_relative_residual": float(
            unified_deposition["field_relative_residual"]
        ),
        "field_energy_bookkeeping_authoritative": bool(
            unified_deposition["field_bookkeeping_authoritative"]
        ),
        "field_energy_bookkeeping_status": _np.asarray(
            "available"
            if unified_deposition["field_bookkeeping_authoritative"]
            else "unavailable"
        ),
        # HR-3A-R keeps full-z scalar records and disk-backed sparse maps only.
        "thermalization_ledger_schema": _np.asarray(
            "khz_filament.thermalization_ledger.v1"
        ),
        "thermalization_source": _np.asarray("hr2_authoritative_deposition"),
        "thermalization_scheme": _np.asarray(
            "complete_microscopic_thermalization"
        ),
        "thermalization_complete_microscopic_approximation": _np.bool_(True),
        "thermalization_authoritative": bool(thermalization["thermalization_authoritative"]),
        "thermalization_unavailable_reason": _np.asarray(
            thermalization["thermalization_unavailable_reason"]
        ),
        "thermalization_value_unit": _np.asarray("J/m^3"),
        "thermalization_representation": _np.asarray(
            "interval_average_volumetric_thermalized_energy"
        ),
        "thermalization_z_edges": _np.asarray(
            longitudinal_schedule.z_edges, dtype=_np.float64
        ),
        "thermalization_dz_intervals": _np.asarray(
            longitudinal_schedule.dz_intervals, dtype=_np.float64
        ),
        "thermalization_mechanism_status_json": _np.asarray(thermalization_mechanism_status_json),
        "thermalization_active_channels": _np.asarray(
            [
                channel for channel, status in thermalization["mechanisms"].items()
                if status["active"]
            ], dtype="U16"
        ),
        "thermalization_inactive_channels": _np.asarray(
            [
                channel for channel, status in thermalization["mechanisms"].items()
                if not status["active"]
            ], dtype="U16"
        ),
        "E_th_ion_interval_J": _np.asarray(
            thermalization["E_th_ion_interval_J"], dtype=_np.float64
        ),
        "E_th_ib_interval_J": _np.asarray(
            thermalization["E_th_ib_interval_J"], dtype=_np.float64
        ),
        "E_th_raman_interval_J": _np.asarray(
            thermalization["E_th_raman_interval_J"], dtype=_np.float64
        ),
        "E_thermal_interval_J": _np.asarray(
            thermalization["E_thermal_interval_J"], dtype=_np.float64
        ),
        "E_th_ion_pulse_J": float(thermalization["E_th_ion_pulse_J"]),
        "E_th_ib_pulse_J": float(thermalization["E_th_ib_pulse_J"]),
        "E_th_raman_pulse_J": float(thermalization["E_th_raman_pulse_J"]),
        "E_thermal_pulse_J": float(thermalization["E_thermal_pulse_J"]),
        "thermalization_t1_status": _np.asarray(thermalization["thermalization_t1_status"]),
        "thermalization_t2_status": _np.asarray(thermalization["thermalization_t2_status"]),
        "thermalization_t3_status": _np.asarray(thermalization["thermalization_t3_status"]),
        "thermalization_first_failed_interval": _np.int64(thermalization["thermalization_first_failed_interval"]),
        "thermalization_first_failed_level": _np.asarray(thermalization["thermalization_first_failed_level"]),
        "thermalization_max_abs_T2_residual_ion_J": float(thermalization["thermalization_max_abs_T2_residual_ion_J"]),
        "thermalization_max_abs_T2_residual_ib_J": float(thermalization["thermalization_max_abs_T2_residual_ib_J"]),
        "thermalization_max_abs_T2_residual_raman_J": float(thermalization["thermalization_max_abs_T2_residual_raman_J"]),
        "thermalization_max_abs_T3_residual_J": float(thermalization["thermalization_max_abs_T3_residual_J"]),
        "thermal_map_archive_schema": _np.asarray(thermal_archive["thermal_map_archive_schema"]),
        "thermal_map_archive_filename": _np.asarray(thermal_archive["thermal_map_archive_filename"]),
        "thermal_map_archive_dtype": _np.asarray(thermal_archive["thermal_map_archive_dtype"]),
        "thermal_map_archive_shape": _np.asarray(thermal_archive["thermal_map_archive_shape"], dtype=_np.int64),
        "thermal_map_archive_complete": bool(thermal_archive["thermal_map_archive_complete"]),
        "thermal_map_archive_enabled": bool(thermal_archive["thermal_map_archive_enabled"]),
        "thermal_map_archive_mode": _np.asarray(thermal_archive["thermal_map_archive_mode"]),
        "thermal_map_archive_disabled_reason": _np.asarray(thermal_archive["thermal_map_archive_disabled_reason"]),
        "thermal_map_target_z_m": _np.asarray(thermal_sample_plan_metadata["target_z_m"], dtype=_np.float64),
        "thermal_map_interval_index": _np.asarray(thermal_sample_plan_metadata["interval_index"], dtype=_np.int64),
        "thermal_map_z_left_m": _np.asarray(thermal_sample_plan_metadata["z_left_m"], dtype=_np.float64),
        "thermal_map_z_right_m": _np.asarray(thermal_sample_plan_metadata["z_right_m"], dtype=_np.float64),
        "thermal_map_z_mid_m": _np.asarray(thermal_sample_plan_metadata["z_mid_m"], dtype=_np.float64),
        "thermal_map_snap_error_m": _np.asarray(thermal_sample_plan_metadata["snap_error_m"], dtype=_np.float64),
        "thermal_map_region": _np.asarray(thermal_sample_plan_metadata["region"]),
        "thermal_map_reason": _np.asarray(thermal_sample_plan_metadata["reason"]),
        "authoritative_hr3a_thermal_source_available": bool(thermalization["thermalization_authoritative"]),
        "authoritative_hr_slow_state_update_active": bool(thermal_slow_state is not None),
        "legacy_slow_heat_compatibility_path_active": bool(
            thermal_slow_state is None and dn_gas is not None
        ),
        # These z-history values are retained for downstream compatibility,
        # but none is a canonical HR-2 total-deposition ledger.
        "legacy_E_dep_z_semantics": _np.asarray(
            "compatibility_z_history_ion_ib_noncanonical"
        ),
        "legacy_E_dep_rot_z_semantics": _np.asarray(
            "compatibility_z_history_raman_non_authoritative"
        ),
        "legacy_E_dep_total_z_semantics": _np.asarray(
            "compatibility_z_history_non_authoritative"
        ),
        "raman_actual_local_negative_min_J_m2": _np.asarray(
            raman_actual_local_negative_min_J_m2_list, dtype=_np.float64
        ),
        "U_rel_change_z":           _np.asarray(U_rel_change_z_list,      dtype=rdtype_np),
        "U_step_change_z":          _np.asarray(U_step_change_z_list,     dtype=rdtype_np),
        "E_loss_from_input_z":      _np.asarray(E_loss_from_input_z_list, dtype=rdtype_np),
        "rho_N2_max_z": _np.asarray(rho_N2_max_z_list, dtype=rdtype_np),
        "rho_O2_max_z": _np.asarray(rho_O2_max_z_list, dtype=rdtype_np),
        "rho_N2_at_rho_total_max_z": _np.asarray(rho_N2_at_rho_total_max_z_list, dtype=rdtype_np),
        "rho_O2_at_rho_total_max_z": _np.asarray(rho_O2_at_rho_total_max_z_list, dtype=rdtype_np),
        "rho_O2_fraction_at_rho_total_max_z": _np.asarray(rho_O2_fraction_at_rho_total_max_z_list, dtype=rdtype_np),
        "dz_used_z": _np.asarray(dz_used_z_list, dtype=rdtype_np),
        "adaptive_rejection_count_z": _np.asarray(adaptive_rejection_count_z_list, dtype=rdtype_np),
        "safety_mode_trigger_count_z": _np.asarray(safety_mode_trigger_count_z_list, dtype=rdtype_np),
        "safety_mode_event_summary": _np.asarray(json.dumps({
            "configured_mode": str(getattr(p, "safety_mode", "off")),
            "trigger_count": int(safety_mode_trigger_count),
            "rejection_count": int(adaptive_rejection_count),
            "source": "live propagation-loop counters",
        }, sort_keys=True)),
        "propagation_observability_schema": _np.asarray("khz_filament.propagation_observability.v1"),

        "fwhm_plasma_z":            _np.asarray(fwhm_plasma_z_list,       dtype=rdtype_np),
        "fwhm_fluence_z":           _np.asarray(fwhm_fluence_z_list,      dtype=rdtype_np),
        "fwhm_time_z":              _np.asarray(fwhm_time_z_list,         dtype=rdtype_np),
        "I_onaxis_max_interp_list": _np.asarray(I_onaxis_max_interp_list, dtype=rdtype_np),
        "raman_absorption_on":      bool(use_raman and raman_absorb_on),
        "raman_absorption_calculated": bool(use_raman and raman_absorption_compute),
        "raman_operator_mode": _np.asarray(r_operator_mode),
        "raman_deposition_authoritative": bool(raman_deposition_authoritative),
        "raman_deposition_source": _np.asarray(raman_deposition_source),
        "raman_operator_feedback_enabled": bool(switches.use_raman_full_operator),
        "raman_operator_applied": _np.asarray(raman_operator_applied_z_list, dtype=_np.bool_),
        "raman_rhs_l2_norm": _np.asarray(raman_rhs_l2_norm_z_list, dtype=rdtype_np),
        "raman_IR_max_raw": _np.asarray(raman_IR_max_raw_z_list, dtype=rdtype_np),
        "raman_target_loss_step_J": _np.asarray(raman_target_loss_step_z_list, dtype=rdtype_np),
        "raman_actual_loss_step_J": _np.asarray(raman_actual_loss_step_z_list, dtype=rdtype_np),
        "raman_closure_residual_step": _np.asarray(raman_closure_residual_step_z_list, dtype=rdtype_np),
        "raman_target_loss_cumulative_J": _np.asarray(raman_target_loss_cumulative_z_list, dtype=rdtype_np),
        "raman_actual_loss_cumulative_J": _np.asarray(raman_actual_loss_cumulative_z_list, dtype=rdtype_np),
        "raman_cumulative_closure_residual": _np.asarray(raman_cumulative_closure_residual_z_list, dtype=rdtype_np),
        "raman_convolution_count_step": _np.asarray(raman_convolution_count_step_z_list, dtype=_np.int64),
        "raman_operator_substep_count": _np.asarray(raman_operator_substep_count_z_list, dtype=_np.int64),
        "raman_operator_walltime_step_s": _np.asarray(raman_operator_walltime_step_z_list, dtype=rdtype_np),
        "raman_energy_projection_iterations": _np.asarray(
            raman_energy_projection_iterations_z_list, dtype=_np.int64),
        "raman_energy_projection_scale_deviation": _np.asarray(
            raman_energy_projection_scale_deviation_z_list, dtype=rdtype_np),
        "raman_energy_projection_initial_residual": _np.asarray(
            raman_energy_projection_initial_residual_z_list, dtype=rdtype_np),
        "linear_walltime_step_s": _np.asarray(linear_walltime_step_z_list, dtype=rdtype_np),
        "ionization_walltime_step_s": _np.asarray(ionization_walltime_step_z_list, dtype=rdtype_np),
        "total_walltime_step_s": _np.asarray(total_walltime_step_z_list, dtype=rdtype_np),
        "gpu_allocated_step_bytes": _np.asarray(gpu_allocated_step_bytes_list, dtype=_np.int64),
        "gpu_reserved_step_bytes": _np.asarray(gpu_reserved_step_bytes_list, dtype=_np.int64),
        "performance_measurement_enabled": bool(measure_performance),
        "operator_energy_diagnostics_enabled": bool(diag_operator_energy),
        "energy_step_start_J": _np.asarray(energy_step_start_z_list, dtype=_np.float64),
        "energy_after_linear_half1_J": _np.asarray(energy_after_linear_half1_z_list, dtype=_np.float64),
        "energy_after_raman_pre_J": _np.asarray(energy_after_raman_pre_z_list, dtype=_np.float64),
        "energy_after_nonraman_J": _np.asarray(energy_after_nonraman_z_list, dtype=_np.float64),
        "energy_after_raman_post_J": _np.asarray(energy_after_raman_post_z_list, dtype=_np.float64),
        "energy_after_linear_half2_J": _np.asarray(energy_after_linear_half2_z_list, dtype=_np.float64),
        "delta_n_rot_applied_semantics": _np.asarray(
            "not_applicable_full_complex_operator" if full_isaacs_mode else "split_delayed_index_applied"
        ),
        "delta_n_elec_applied_semantics": _np.asarray(
            "equivalent_n2_I_trace_full_complex_operator"
            if complete_operator_enabled else "scalar_deltan_elec_applied"
        ),
        "dphi_kerr_semantics": _np.asarray(
            "not_applicable_scalar_phase_full_complex_operator"
            if complete_operator_enabled else "scalar_dphi_kerr_applied"
        ),
        "self_steepening_semantics": _np.asarray(
            "full_product_derivative_D_S_in_complete_complex_operator"
            if complete_operator_enabled else (
                "scalar_shock_intensity_applied"
                if switches.use_self_steepening else "disabled"
            )
        ),
        "raman_closure_residual_semantics": _np.asarray(
            "field_vs_eq10" if full_isaacs_on else "not_applicable_feedback_off_or_legacy"
        ),
        "raman_actual_loss_evaluation": _np.asarray(
            "stable_component_difference_float64" if full_isaacs_mode
            else "legacy_fluence_subtraction"
        ),
        "Qacc_raman": to_cpu(Qacc_raman).astype(rdtype_np, copy=False),
        "ionization_loss_on": bool(switches.use_ionization_loss),
        "ionization_solver_on": bool(switches.use_ionization_solver),
        "E_dep_rot_z": _np.asarray(E_dep_rot_z_list, dtype=rdtype_np),
        "alpha_R_max_z": _np.asarray(alpha_R_max_z_list, dtype=rdtype_np),
        "alpha_R_mean_z": _np.asarray(alpha_R_mean_z_list, dtype=rdtype_np),
        "alpha_R_eff_z": _np.asarray(alpha_R_eff_z_list, dtype=rdtype_np),
        "alpha_R_closed_z": _np.asarray(alpha_R_closed_z_list, dtype=rdtype_np),
        "alpha_R_raw_max_z": _np.asarray(alpha_R_raw_max_z_list, dtype=rdtype_np),
        "alpha_R_applied_max_z": _np.asarray(alpha_R_applied_max_z_list, dtype=rdtype_np),
        "IR_max_z": _np.asarray(IR_max_z_list, dtype=rdtype_np),
        "IR_abs_max_z": _np.asarray(IR_abs_max_z_list, dtype=rdtype_np),
        "delta_n_elec_max_z": _np.asarray(delta_n_elec_max_z_list, dtype=rdtype_np),
        "delta_n_rot_max_z": _np.asarray(delta_n_rot_max_z_list, dtype=rdtype_np),
        "delta_n_elec_peak_z": _np.asarray(delta_n_elec_peak_z_list, dtype=rdtype_np),
        "delta_n_rot_peak_z": _np.asarray(delta_n_rot_peak_z_list, dtype=rdtype_np),
        "delta_n_elec_applied_max_z": _np.asarray(delta_n_elec_applied_max_z_list, dtype=rdtype_np),
        "delta_n_rot_applied_max_z": _np.asarray(delta_n_rot_applied_max_z_list, dtype=rdtype_np),
        "alpha_ion_raw_max_z": _np.asarray(alpha_ion_raw_max_z_list, dtype=rdtype_np),
        "alpha_ion_corr_max_z": _np.asarray(alpha_ion_corr_max_z_list, dtype=rdtype_np),
        "alpha_ion_applied_max_z": _np.asarray(alpha_ion_applied_max_z_list, dtype=rdtype_np),
        "alpha_ib_max_z": _np.asarray(alpha_ib_max_z_list, dtype=rdtype_np),
        "alpha_total_max_z": _np.asarray(alpha_total_max_z_list, dtype=rdtype_np),
        "delta_n_plasma_min_z": _np.asarray(delta_n_plasma_min_z_list, dtype=rdtype_np),
        "delta_n_plasma_applied_min_z": _np.asarray(delta_n_plasma_applied_min_z_list, dtype=rdtype_np),
        "dphi_kerr_max_abs_z": _np.asarray(dphi_kerr_max_abs_z_list, dtype=rdtype_np),
        "dphi_elec_max_abs_z": _np.asarray(dphi_elec_max_abs_z_list, dtype=rdtype_np),
        "dphi_rot_max_abs_z": _np.asarray(dphi_rot_max_abs_z_list, dtype=rdtype_np),
        "dphi_elec_applied_max_abs_z": _np.asarray(dphi_elec_applied_max_abs_z_list, dtype=rdtype_np),
        "dphi_rot_applied_max_abs_z": _np.asarray(dphi_rot_applied_max_abs_z_list, dtype=rdtype_np),
        "dphi_plasma_raw_max_abs_z": _np.asarray(dphi_plasma_raw_max_abs_z_list, dtype=rdtype_np),
        "dphi_plasma_applied_max_abs_z": _np.asarray(dphi_plasma_applied_max_abs_z_list, dtype=rdtype_np),
        "dphi_plasma_max_abs_z": _np.asarray(dphi_plasma_max_abs_z_list, dtype=rdtype_np),
        "n2_elec_used": float(n2_elec),
        "n_R_used": float(n_R),
        "f_R_ignored_rot_sinexp": bool(fR_ignored_rot_sinexp),
        "f_R_used_historical_fr_mixture": float(fR_used_historical_fr_mixture),
        "historical_raman_omega_R_rad_s": float(historical_omega_R),
        "historical_raman_Gamma_R_1_s": float(historical_Gamma_R),
        "raman_absorption_model": absorption_model,  # 便于外部读
        "ionization_operator_correction_on": bool(use_ion_op_corr),
        "ionization_operator_method": ion_op_method,
        "nonlinear_use_electronic_kerr": bool(switches.use_electronic_kerr),
        "nonlinear_use_raman_phase": bool(switches.use_raman_phase),
        "nonlinear_use_raman_full_operator": bool(switches.use_raman_full_operator),
        "nonlinear_use_plasma_phase": bool(switches.use_plasma_phase),
        "nonlinear_use_ionization_loss": bool(switches.use_ionization_loss),
        "nonlinear_use_raman_absorption": bool(switches.use_raman_absorption),
        "nonlinear_use_self_steepening": bool(switches.use_self_steepening),
        "nonlinear_use_ionization_solver": bool(switches.use_ionization_solver),
    }
    if hr3b_ledger is not None:
        diag.update({
            "hr3b_mapping_schema": _np.asarray("khz_filament.hr3b.post_acoustic.v1"),
            "hr3b_authoritative": bool(hr3b_ledger["hr3b_authoritative"]),
            "hr3b_source_authority_status": _np.asarray(hr3b_ledger["hr3b_source_authority_status"]),
            "hr3b_mapping_status": _np.asarray(hr3b_ledger["hr3b_mapping_status"]),
            "hr3b_sign_status": _np.asarray(hr3b_ledger["hr3b_sign_status"]),
            "hr3b_thermodynamic_status": _np.asarray(hr3b_ledger["hr3b_thermodynamic_status"]),
            "hr3b_first_failed_interval": _np.int64(hr3b_ledger["hr3b_first_failed_interval"]),
            "hr3b_first_failed_level": _np.asarray(hr3b_ledger["hr3b_first_failed_level"]),
            "delta_n_increment_min": _np.asarray(hr3b_ledger["delta_n_increment_min"], dtype=_np.float64),
            "delta_n_increment_onaxis": _np.asarray(hr3b_ledger["delta_n_increment_onaxis"], dtype=_np.float64),
            "delta_n_state_min_after_update": _np.asarray(hr3b_ledger["delta_n_state_min_after_update"], dtype=_np.float64),
            "delta_n_state_onaxis_after_update": _np.asarray(hr3b_ledger["delta_n_state_onaxis_after_update"], dtype=_np.float64),
            "Delta_T_impulse_max": _np.asarray(hr3b_ledger["Delta_T_impulse_max"], dtype=_np.float64),
            "Delta_T_post_max": _np.asarray(hr3b_ledger["Delta_T_post_max"], dtype=_np.float64),
            "delta_rho_min": _np.asarray(hr3b_ledger["delta_rho_min"], dtype=_np.float64),
            "hr3b_mapping_max_abs_residual": _np.asarray(hr3b_ledger["hr3b_mapping_max_abs_residual"], dtype=_np.float64),
            "hr3b_isobaric_max_abs_residual": _np.asarray(hr3b_ledger["hr3b_isobaric_max_abs_residual"], dtype=_np.float64),
            "hr3b_state_schema": _np.asarray(hr3b_state_metadata["hr3b_state_schema"]),
            "hr3b_state_filename": _np.asarray(hr3b_state_metadata["hr3b_state_filename"]),
            "hr3b_state_dtype": _np.asarray(hr3b_state_metadata["hr3b_state_dtype"]),
            "hr3b_state_shape": _np.asarray(hr3b_state_metadata["hr3b_state_shape"], dtype=_np.int64),
            "hr3b_state_interval_centered": bool(hr3b_state_metadata["hr3b_state_interval_centered"]),
            "hr3b_state_disk_backed": bool(hr3b_state_metadata["hr3b_state_disk_backed"]),
            "hr3b_map_archive_schema": _np.asarray(hr3b_archive["hr3b_map_archive_schema"]),
            "hr3b_increment_archive_filename": _np.asarray(hr3b_archive["hr3b_increment_archive_filename"]),
            "hr3b_state_after_archive_filename": _np.asarray(hr3b_archive["hr3b_state_after_archive_filename"]),
            "hr3b_map_archive_dtype": _np.asarray(hr3b_archive["hr3b_map_archive_dtype"]),
            "hr3b_map_archive_shape": _np.asarray(hr3b_archive["hr3b_map_archive_shape"], dtype=_np.int64),
            "hr3b_map_archive_complete": bool(hr3b_archive["hr3b_map_archive_complete"]),
            "hr3b_map_archive_enabled": bool(hr3b_archive["hr3b_map_archive_enabled"]),
            "hr3b_map_archive_disabled_reason": _np.asarray(hr3b_archive["hr3b_map_archive_disabled_reason"]),
            "hr3b_beta_th_m3_J": float(hr3b_parameters["beta_th"]),
        })
    for prefix, grid_metadata in (
        ("optical_grid_", deposition_contract.transverse_grid.optical_grid),
        ("thermal_grid_", deposition_contract.transverse_grid.thermal_grid),
    ):
        diag[f"{prefix}Nx"] = _np.int64(grid_metadata.Nx)
        diag[f"{prefix}Ny"] = _np.int64(grid_metadata.Ny)
        diag[f"{prefix}dx"] = float(grid_metadata.dx)
        diag[f"{prefix}dy"] = float(grid_metadata.dy)
        diag[f"{prefix}Lx"] = float(grid_metadata.Lx)
        diag[f"{prefix}Ly"] = float(grid_metadata.Ly)
    if diag_linear_halfstep_energy:
        diag["linear_halfstep_energy_diagnostics_enabled"] = _np.bool_(True)
        diag["linear_halfstep_energy_sign_convention"] = _np.asarray(
            "field_delta=U_after-U_before; explicit_loss>0; residual=field_delta+explicit_loss"
        )
        for half_index, records in ((1, linear_halfstep_1_z_list), (2, linear_halfstep_2_z_list)):
            for key in records[0]:
                diag[f"linear_halfstep_{half_index}_{key}"] = _np.asarray(
                    [record[key] for record in records], dtype=_np.float64
                )
    if diag_bk_nee_profile:
        diag["bk_nee_profile_enabled"] = _np.bool_(True)
        for half_index, records in ((1, linear_profile_halfstep_1_z_list), (2, linear_profile_halfstep_2_z_list)):
            diag[f"bk_nee_profile_halfstep_{half_index}_json"] = _np.asarray(
                [json.dumps(record, sort_keys=True) for record in records]
            )
    if record_onaxis_rho_time and (rho_onaxis_time_list is not None and len(rho_onaxis_time_list) > 0):
        diag["rho_onaxis_t_z"] = _np.stack(rho_onaxis_time_list, axis=0).astype(rdtype_np, copy=False)

    validation = validate_nonlinear_diagnostics(diag)
    diag["diagnostic_validation_passed"] = _np.bool_(validation["passed"])
    diag["diagnostic_validation_trace_count"] = _np.int64(validation["z_records"])
    diag["diagnostic_all_zero_traces"] = _np.asarray(validation["all_zero_traces"], dtype="U64")


    # Qacc/Q2D is legacy 2-D slow-heat compatibility output [J/m^2].
    return E, to_cpu(Qacc).astype(rdtype_np, copy=False), diag
