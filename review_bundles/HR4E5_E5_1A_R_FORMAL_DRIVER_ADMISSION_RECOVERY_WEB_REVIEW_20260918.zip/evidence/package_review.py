from __future__ import annotations

import csv
import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
WORK = Path(__file__).resolve().parent
REVIEW_SHA = "588872979bcbef8f3b278e76a02a4b3010fac6f7"
CODE_SHA = "217f74587edcdf739127602afd73b2b830fc77bb"
BASE_SHA = "b9b5f31d0875ee92b9ea98d23a0659a00e18fdde"
ORIGINAL_BASE = "131daa541ac37e54d43b29cd3bfc12ba83c3b91d"
STAGE = WORK / f"stage_{REVIEW_SHA[:12]}_retry2"
VALIDATED = WORK / f"validated_{REVIEW_SHA[:12]}_retry2"
ZIP_PATH = ROOT / "review_bundles" / "HR4E5_E5_1A_R_FORMAL_DRIVER_ADMISSION_RECOVERY_WEB_REVIEW_20260918.zip"
VALIDATION_PATH = WORK / "delivery_validation.json"


REPORTS = [
    "docs/physics_decisions/hr4e5/e5_1/E5_1A_R_COMPLETION_REPORT_20260918.md",
    "docs/physics_decisions/hr4e5/e5_1/E5_1A_R_TEST_RESULTS.json",
    "docs/physics_decisions/hr4e5/e5_1/E5_1A_CONTRACT.json",
    "docs/physics_decisions/hr4e5/e5_1/E5_1A_CHANGE_AND_QUALIFICATION_MATRIX.md",
    "docs/physics_decisions/hr4e5/e5_1/E5_1A_STORAGE_RETENTION_CONTRACT.md",
    "docs/physics_decisions/hr4e5/e5_1/E5_1A_RESOURCE_BUDGET.csv",
    "docs/physics_decisions/hr4e5/e5_1/E5_1A_IMPLEMENTATION_REPORT_20260916.md",
    "docs/physics_decisions/hr4e5/e5_1/E5_1A_TEST_RESULTS.json",
]

SOURCE = [
    "AGENTS.md",
    "Filament_python/KHz_filament/hr4e5_evidence.py",
    "Filament_python/KHz_filament/hr4e5_formal_entry.py",
    "Filament_python/KHz_filament/hr4e5_paired_campaign.py",
    "Filament_python/KHz_filament/hr4e5_storage.py",
    "Filament_python/KHz_filament/hr4e5s_streaming.py",
    "Filament_python/KHz_filament/hr4d_pulse_lifecycle.py",
    "Filament_python/KHz_filament/hr4c_state.py",
    "Filament_python/KHz_filament/hr4e_timestep.py",
    "Filament_python/KHz_filament/propagate.py",
    "Filament_python/KHz_filament/runner.py",
    "Filament_python/tests/hr4e5_fixture_campaign.py",
    "Filament_python/tests/test_hr4e5_e5_1a.py",
    "Filament_python/tests/test_hr4e5_e5_1a_entry_refusals.py",
    "Filament_python/tests/test_hr4e5_e5_1a_r.py",
    "Filament_python/tools/run_local_tests.ps1",
    "Filament_python/tools/hpc_ops/provenance_v2.py",
]


def run_git(*args: str) -> str:
    result = subprocess.run(
        ["git", *args], cwd=ROOT, check=True, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8",
    )
    return result.stdout


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def copy_repo_file(repo_path: str, section: str) -> None:
    source = ROOT / repo_path
    if not source.is_file():
        raise FileNotFoundError(source)
    target = STAGE / section / Path(repo_path).name
    if section == "source":
        target = STAGE / section / repo_path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def write_patches() -> None:
    patch_dir = STAGE / "patches"
    patch_dir.mkdir(parents=True)
    commands = [
        ("repair_base_to_review.diff", ("diff", "--binary", f"{BASE_SHA}..{REVIEW_SHA}", "--")),
        ("repair_base_to_review.stat", ("diff", "--stat", f"{BASE_SHA}..{REVIEW_SHA}", "--")),
        ("original_base_to_review_scope.diff", ("diff", "--binary", f"{ORIGINAL_BASE}..{REVIEW_SHA}", "--")),
        ("original_base_to_review_scope.stat", ("diff", "--stat", f"{ORIGINAL_BASE}..{REVIEW_SHA}", "--")),
    ]
    for name, args in commands:
        (patch_dir / name).write_text(run_git(*args), encoding="utf-8", newline="\n")


def write_readme() -> None:
    text = f"""# E5-1A-R web review bundle

Status: **E5_1A_PARTIAL / BLOCKED_BY_FORMAL_DRIVER_AND_RECOVERY_QUALIFICATION**.

- repair base: `{BASE_SHA}`
- code/test commit: `{CODE_SHA}`
- report/review commit: `{REVIEW_SHA}`
- architecture: existing Streaming remains authoritative
- limits: 300 GiB campaign, 64 GiB included final-output cap
- runtime orchestration changed: yes
- scientific operators changed: no
- Slurm/GPU/S5 actions: no
- B/C: not started and not authorized

Start with [the completion report](reports/E5_1A_R_COMPLETION_REPORT_20260918.md),
then inspect [structured results](reports/E5_1A_R_TEST_RESULTS.json), the four
modified modules under `source/`, and `patches/repair_base_to_review.diff`.

The bundle records locally passing backend, 13 focused repair tests, 43 total
E5-1A tests, 34 Streaming/HR4D regressions, sanity and compileall. R01/R07/R08/
R09 remain local or fixture evidence. The missing unique production runner,
ordinary R/C ownership binding, writer-lifetime integration and complete
non-fixture positive GC/terminal path prevent READY_FOR_REVIEW.
"""
    (STAGE / "WEB_REVIEW_README.md").write_text(text, encoding="utf-8", newline="\n")


def git_blob(repo_path: str) -> str:
    return run_git("rev-parse", f"{REVIEW_SHA}:{repo_path}").strip()


def build_index() -> list[dict[str, object]]:
    repo_lookup: dict[str, str] = {}
    for repo_path in REPORTS:
        repo_lookup[f"reports/{Path(repo_path).name}"] = repo_path
    for repo_path in SOURCE:
        repo_lookup[f"source/{repo_path}"] = repo_path
    entries = []
    for path in sorted(p for p in STAGE.rglob("*") if p.is_file()):
        relative = path.relative_to(STAGE).as_posix()
        if relative in {"WEB_REVIEW_INDEX.json", "SHA256SUMS.txt"}:
            continue
        role = relative.split("/", 1)[0] if "/" in relative else "readme"
        item: dict[str, object] = {
            "path": relative,
            "sha256": sha256(path),
            "role": role,
            "source_commit": REVIEW_SHA if role in {"reports", "source", "readme", "patches"} else CODE_SHA,
        }
        repo_path = repo_lookup.get(relative)
        if repo_path is not None:
            item["repo_path"] = repo_path
            item["git_blob"] = git_blob(repo_path)
        entries.append(item)
    return entries


def write_index_and_sums() -> None:
    entries = build_index()
    index = {
        "schema": "filament.hr4e5.e5_1a_r.web_review_index.v1",
        "status": "E5_1A_PARTIAL",
        "blocker": "FORMAL_DRIVER_AND_RECOVERY_QUALIFICATION",
        "repair_base": BASE_SHA,
        "code_test_commit": CODE_SHA,
        "review_commit": REVIEW_SHA,
        "entries": entries,
    }
    index_path = STAGE / "WEB_REVIEW_INDEX.json"
    index_path.write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    sum_paths = sorted(p for p in STAGE.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt")
    sums = "".join(f"{sha256(path)}  {path.relative_to(STAGE).as_posix()}\n" for path in sum_paths)
    (STAGE / "SHA256SUMS.txt").write_text(sums, encoding="utf-8", newline="\n")


def write_zip() -> None:
    ZIP_PATH.parent.mkdir(parents=True, exist_ok=True)
    if ZIP_PATH.exists():
        raise FileExistsError(f"refusing to overwrite existing bundle: {ZIP_PATH}")
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(p for p in STAGE.rglob("*") if p.is_file()):
            archive.write(path, path.relative_to(STAGE).as_posix())


def validate_zip() -> dict[str, object]:
    if VALIDATED.exists():
        raise FileExistsError(VALIDATED)
    VALIDATED.mkdir(parents=True)
    with zipfile.ZipFile(ZIP_PATH, "r") as archive:
        bad_crc = archive.testzip()
        names = archive.namelist()
        if bad_crc is not None:
            raise ValueError(f"CRC failure: {bad_crc}")
        if len(names) != len(set(names)):
            raise ValueError("duplicate ZIP path")
        for name in names:
            posix = PurePosixPath(name)
            if posix.is_absolute() or ".." in posix.parts or "\\" in name or not name:
                raise ValueError(f"unsafe ZIP path: {name}")
        archive.extractall(VALIDATED)

    index = json.loads((VALIDATED / "WEB_REVIEW_INDEX.json").read_text(encoding="utf-8"))
    indexed = {entry["path"] for entry in index["entries"]}
    expected_indexed = set(names) - {"WEB_REVIEW_INDEX.json", "SHA256SUMS.txt"}
    if indexed != expected_indexed:
        raise ValueError("INDEX coverage mismatch")
    for entry in index["entries"]:
        if sha256(VALIDATED / entry["path"]) != entry["sha256"]:
            raise ValueError(f"INDEX hash mismatch: {entry['path']}")

    sum_rows = {}
    for line in (VALIDATED / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        sum_rows[relative] = digest
    expected_sums = set(names) - {"SHA256SUMS.txt"}
    if set(sum_rows) != expected_sums:
        raise ValueError("SHA256SUMS coverage mismatch")
    for relative, digest in sum_rows.items():
        if sha256(VALIDATED / relative) != digest:
            raise ValueError(f"SHA256SUMS mismatch: {relative}")

    json_count = 0
    for path in VALIDATED.rglob("*.json"):
        json.loads(path.read_text(encoding="utf-8"))
        json_count += 1
    csv_count = 0
    for path in VALIDATED.rglob("*.csv"):
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.reader(stream))
        if not rows or any(len(row) != len(rows[0]) for row in rows):
            raise ValueError(f"CSV width mismatch: {path}")
        csv_count += 1

    link_count = 0
    link_pattern = re.compile(r"\[[^\]]+\]\((?!https?://|#)([^)]+)\)")
    markdown_to_check = [VALIDATED / "WEB_REVIEW_README.md"]
    markdown_to_check.extend(sorted((VALIDATED / "reports").glob("*.md")))
    for path in markdown_to_check:
        text = path.read_text(encoding="utf-8")
        if not text.strip():
            raise ValueError(f"empty markdown: {path}")
        for match in link_pattern.finditer(text):
            raw = match.group(1).split("#", 1)[0]
            if raw and not (path.parent / raw).resolve().is_file():
                raise ValueError(f"broken markdown link: {path} -> {raw}")
            link_count += 1
    return {
        "status": "PASS",
        "zip_path": str(ZIP_PATH),
        "zip_sha256": sha256(ZIP_PATH),
        "zip_size_bytes": ZIP_PATH.stat().st_size,
        "entries": len(names),
        "crc": "PASS",
        "safe_unique_paths": "PASS",
        "index_coverage_and_hashes": "PASS",
        "sha256sums_coverage_and_hashes": "PASS",
        "json_files_parsed": json_count,
        "csv_files_checked": csv_count,
        "markdown_links_checked": link_count,
    }


def main() -> None:
    if STAGE.exists() or VALIDATED.exists():
        raise FileExistsError("staging or validation directory already exists")
    STAGE.mkdir(parents=True)
    for repo_path in REPORTS:
        copy_repo_file(repo_path, "reports")
    for repo_path in SOURCE:
        copy_repo_file(repo_path, "source")
    evidence_dir = STAGE / "evidence"
    evidence_dir.mkdir(parents=True)
    for path in sorted((WORK / "evidence").iterdir()):
        if path.is_file():
            shutil.copy2(path, evidence_dir / path.name)
    historical = ROOT / ".e5_1a_review" / "evidence"
    for name in ("integrated_fixture.json", "independent_review_disposition.json", "budget_model.json"):
        source = historical / name
        if source.is_file():
            shutil.copy2(source, evidence_dir / f"historical_{name}")
    shutil.copy2(Path(__file__), evidence_dir / "package_review.py")
    write_patches()
    write_readme()
    write_index_and_sums()
    write_zip()
    result = validate_zip()
    VALIDATION_PATH.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
