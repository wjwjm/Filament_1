"""Bounded metadata only; imports no optical/hydro execution modules."""
import importlib.util
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
path = root / 'Filament_python/KHz_filament/longitudinal.py'
spec = importlib.util.spec_from_file_location('e50_longitudinal_metadata', path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
config = json.loads((root / 'Filament_python/results/hr4e5s_s5_1r_238355_failure_audit/real_post_input_config.json').read_text(encoding='utf-8'))
p = config['propagation']
kwargs = {k:p[k] for k in ('dz','z_max','focus_window_step','focus_center_m','focus_halfwidth_m','dz_focus')}
full = module.build_longitudinal_schedule(**kwargs)
K = 8048
prefix = module.LongitudinalSchedule(z_edges=full.z_edges[:K+1], dz_intervals=full.dz_intervals[:K], intervals=full.intervals[:K], z_start=0.0, z_end=full.z_edges[K])
kwargs['z_max'] = prefix.z_end
rebuilt = module.build_longitudinal_schedule(**kwargs)
result = dict(method='existing longitudinal metadata classes only; no propagation/hydro/large scientific arrays', full_K=full.n_intervals, K=K, z_start=prefix.z_start, z_end=prefix.z_end, z_end_hex=prefix.z_end.hex(), prefix_validated=prefix.validate(), rebuilt_edges_exact=rebuilt.z_edges == prefix.z_edges, rebuilt_dz_exact=rebuilt.dz_intervals == prefix.dz_intervals, final_original_dz=prefix.dz_intervals[-1], final_rebuilt_dz=rebuilt.dz_intervals[-1], design_rule='pass sliced LongitudinalSchedule with unchanged original interval dz; never rebuild at rounded endpoint')
(Path(__file__).parent/'domain_metadata_check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
