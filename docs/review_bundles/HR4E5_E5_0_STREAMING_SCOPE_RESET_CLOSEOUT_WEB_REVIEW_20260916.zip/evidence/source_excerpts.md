# Fixed source evidence

Source commit: `cbfe2e38172b5221d739df80b032e4dee9fab7e3`. Original full small source copies preserve line numbers.

- [Filament_python/KHz_filament/hr4e5s_streaming.py](source/Filament_python/KHz_filament/hr4e5s_streaming.py)
- [Filament_python/KHz_filament/hr4e5s_s3.py](source/Filament_python/KHz_filament/hr4e5s_s3.py)
- [Filament_python/KHz_filament/hr4e5s_s5.py](source/Filament_python/KHz_filament/hr4e5s_s5.py)
- [Filament_python/KHz_filament/hr4e5s_s5_final.py](source/Filament_python/KHz_filament/hr4e5s_s5_final.py)
- [Filament_python/KHz_filament/propagate.py](source/Filament_python/KHz_filament/propagate.py)
- [Filament_python/KHz_filament/runner.py](source/Filament_python/KHz_filament/runner.py)
- [Filament_python/KHz_filament/grids.py](source/Filament_python/KHz_filament/grids.py)
- [Filament_python/KHz_filament/longitudinal.py](source/Filament_python/KHz_filament/longitudinal.py)
- [Filament_python/KHz_filament/thermalization.py](source/Filament_python/KHz_filament/thermalization.py)
- [Filament_python/KHz_filament/slow_state.py](source/Filament_python/KHz_filament/slow_state.py)
- [Filament_python/KHz_filament/hr4c_state.py](source/Filament_python/KHz_filament/hr4c_state.py)
- [Filament_python/KHz_filament/hr4d_pulse_lifecycle.py](source/Filament_python/KHz_filament/hr4d_pulse_lifecycle.py)
- [Filament_python/KHz_filament/hr4e_timestep.py](source/Filament_python/KHz_filament/hr4e_timestep.py)
- [Filament_python/KHz_filament/config.py](source/Filament_python/KHz_filament/config.py)
- [Filament_python/KHz_filament/confio.py](source/Filament_python/KHz_filament/confio.py)
- [Filament_python/tools/hr4e5s_s5_final.sbatch](source/Filament_python/tools/hr4e5s_s5_final.sbatch)
- [Filament_python/tools/monitor_hr4e5s_s5_final.py](source/Filament_python/tools/monitor_hr4e5s_s5_final.py)
- [Filament_python/tools/hpc_ops/provenance_v2.py](source/Filament_python/tools/hpc_ops/provenance_v2.py)

Primary call map: streaming create 342-406; current_fields 828-834; commit/enqueue 857-966; claim 1028-1045; recovery 1127-1176; barrier/promotion 1178-1266. S3 source view 342-356; optical 409-493; Batch 495-520; exact 571-627. Propagate PRE read 960; HR3/hook 1182-1217. New glue names are design proposals, not symbols in these copies.
