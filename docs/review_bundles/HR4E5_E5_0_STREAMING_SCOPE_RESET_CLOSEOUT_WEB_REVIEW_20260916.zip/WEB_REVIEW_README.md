# E5-0 Streaming scope reset closeout — web review

Status: `E5_0_STREAMING_CLOSEOUT_READY_FOR_WEB_REVIEW`. Preparation contract complete; web acceptance still required for CLOSED.

Two corrections: existing Streaming CURRENT/POST/NEXT remains production authority; hydro may start after each durable POST while that pulse's optical continues. HR4C production replacement and whole-POST-before-hydro are superseded.

Start/source SHA: `cbfe2e38172b5221d739df80b032e4dee9fab7e3`. S5 execution SHA from historical receipt: `cd456ff8413cbc041d2d60b9b64007a1554028a1`.
Document SHA: `c377178e909d795b1fce0d4d162ab14845c9c264`. Packaging commit is created **after** this immutable ZIP; obtain it from the external receipt/Git history. It is not the document or execution SHA.

Read [closeout matrix](E5_0_CLOSEOUT_MATRIX.md), then [interface](docs/physics_decisions/hr4e5/e5_0/formal_hr4e5_e5_0_authority_interface_design_20260916.md), [E5-1](docs/physics_decisions/hr4e5/e5_1/formal_hr4e5_e5_1_small_case_candidate_20260916.md), and [resource CSV](docs/physics_decisions/hr4e5/e5_0/formal_hr4e5_e5_0_resource_budget.csv).

Recommended engineering candidate: N=3, K=8048, original-input continuous prefix through z=0.8047999999999277m; 1006 full blocks, original interval dz retained. Scientific payload 669587300928 bytes; recommended availability/quota 851693145010 bytes including allowances and 25% reserve.

Unreleased gates: S5 terminal evidence; derived input acceptance; separately authorized glue/tests; materialized PRE0/input provenance; quota/QoS/device/observed memory/I/O; separate HPC submission authorization. No runtime/science/job changes.

Old ZIP and original HPC snapshot preserved. Historical JSON/config files retain their original schemas and facts; they are evidence, not current candidate manifests. Four small local evidence files were explicitly selected: config/source match original raw hashes; prepared input/LUT are separately labeled earlier local snapshots, with actual hashes and historical distinction in the revised audit; unrelated untracked trees are excluded.

INDEX records raw transport SHA for every payload and Git blob plus canonical-LF SHA for tracked text, using repository provenance_v2 helpers. Generated items have source_commit=null and generation method. INDEX excludes itself and SHA256SUMS to avoid a hash cycle. SHA256SUMS covers everything except itself. Final extraction/CRC/hash/link results and outer ZIP hash are in the external receipt; no post-verification ZIP edits.
