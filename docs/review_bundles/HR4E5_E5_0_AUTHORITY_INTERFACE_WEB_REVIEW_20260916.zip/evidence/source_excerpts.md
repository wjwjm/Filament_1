# Source excerpts used for the E5-0 authority decision

All excerpts are from review SHA 075a3f796dc7722fa167cef64b3b0685271382e0. Line numbers are one-based.

| Source | Blob | Functions / lines | Decision use |
| --- | --- | --- | --- |
| hr4d_pulse_lifecycle.py | 8adaf3bdd33093efb9fa0d2f7670dae3adea08b2 | controller 151-179; interpulse 294-318; pulse train 324-361 | sole HR4C authority, exact resume construction, fresh source and terminal lifecycle |
| hr4c_state.py | 6f82e2a6291d3ac42deb5a15a56ef5f570ca87d0 | open 132-143; initializer 166-197; commit 350-376 | persistent slots, PRE_0 zero-batch initialization and atomic commit |
| hr4e5s_streaming.py | d6c1341791fdd7fd131136bac7939997e24f94d8 | atomic NPZ 212-240; POST 875-920; NEXT 1047-1073; barrier/promotion 1178-1255 | qualification staging/restart precedent, not formal authority |
| hr4e5s_s3.py | 769c9af73bbbdbc817e7680e4648c30c58df83cb | initializer 387-398 | caller-side selected/zero allocations and S3-only qualification initialization |
| runner.py | cfa174197e2aefc3e484b18a33ea05d3efde1a00 | 481-504; 540-545 | immutable source plus fresh optical copy every pulse |
| propagate.py | f156111398415c2b92e4609ccc1da075fcf5d1e3 | 957-963; 1183-1216 | PRE delta-n read and owned HR-3 POST interface |

## hr4d_pulse_lifecycle.py

~~~text
Lines 151-179:
  151: class HR4DPulseController:
  152:     """Restart-safe PRE/POST state machine with HR-4C as the sole authority store."""
  153: 
  154:     def __init__(
  155:         self, *, output_path: str, n_intervals: int, shape, dtype, z_edges, dx: float, dy: float,
  156:         n_pulses: int, f_rep: float, dt_hydro: float, batch_intervals: int,
  157:         chi: float, nu: float, n0: float, gravity_x: float = 0.0, gravity_y: float = -9.81,
  158:         cfl_limit: float = 1.0, resume: bool = False,
  159:     ):
  160:         self.n_pulses = _positive_integer(n_pulses, "n_pulses")
  161:         self.f_rep = _positive_finite(f_rep, "f_rep")
  162:         self.dt_hydro = _positive_finite(dt_hydro, "dt_hydro")
  163:         self.batch_intervals = _positive_integer(batch_intervals, "batch_intervals")
  164:         self.chi, self.nu, self.n0 = float(chi), float(nu), _positive_finite(n0, "n0")
  165:         self.gravity_x, self.gravity_y, self.cfl_limit = float(gravity_x), float(gravity_y), float(cfl_limit)
  166:         common = dict(
  167:             output_path=output_path, n_intervals=n_intervals, shape=shape, dtype=dtype,
  168:             z_edges=z_edges, dx=dx, dy=dy,
  169:         )
  170:         initial_metadata = self._metadata_for(
  171:             pulse_index=0, phase=HR4D_PHASE_PRE, source_generation=None,
  172:             state_generation=0, transition="initial_state",
  173:         )
  174:         self.store = (
  175:             HR4CThreeFieldStore.open_existing(**common)
  176:             if resume else HR4CThreeFieldStore(**common, authoritative_metadata=initial_metadata)
  177:         )
  178:         if resume:
  179:             self._validate_authoritative_metadata()
Lines 294-318:
  294:     def run_interpulse_transition(
  295:         self, *, failure_injector: Callable[[int, int], None] | None = None,
  296:     ) -> dict[str, object]:
  297:         if self.next_action != "interpulse":
  298:             raise ValueError("HR-4D lifecycle is not ready for interpulse evolution")
  299:         metadata = self.metadata
  300:         schedule = build_interpulse_step_schedule(f_rep=self.f_rep, dt_hydro=self.dt_hydro)
  301:         source = int(self.store.manifest["generation"])
  302:         target = self._metadata_for(
  303:             pulse_index=int(metadata["pulse_index"]) + 1, phase=HR4D_PHASE_PRE,
  304:             source_generation=source, state_generation=source + 1, transition="interpulse_pre_commit",
  305:         )
  306:         result = evolve_hr4_full_z(
  307:             self.store, dt_hydro=self.dt_hydro, n_hydro_steps=schedule.full_step_count,
  308:             step_schedule=schedule.entries, batch_intervals=self.batch_intervals,
  309:             chi=self.chi, nu=self.nu, n0=self.n0, gravity_x=self.gravity_x,
  310:             gravity_y=self.gravity_y, cfl_limit=self.cfl_limit, failure_injector=failure_injector,
  311:             authoritative_metadata=target,
  312:         )
  313:         result.update({
  314:             "interpulse_duration_s": schedule.duration_s,
  315:             "full_step_count": schedule.full_step_count,
  316:             "remainder_s": schedule.remainder_s,
  317:         })
  318:         return result
Lines 324-361:
  324: def run_one_pulse_transition(
  325:     controller: HR4DPulseController, source_template, pulse_runner: Callable[[Any, HR4DPulseTransaction], Any],
  326: ):
  327:     """Use a fresh source copy, then commit POST only after the full pulse succeeds."""
  328:     fresh_field = source_template.copy()
  329:     transaction = controller.begin_pulse_transition()
  330:     try:
  331:         result = pulse_runner(fresh_field, transaction)
  332:         transaction.finalize()
  333:         return result
  334:     except Exception as error:
  335:         if not transaction.closed:
  336:             controller.abort_pulse_transition(reason=type(error).__name__)
  337:             transaction.closed = True
  338:         raise
  339: 
  340: 
  341: def run_hr4_pulse_train(
  342:     controller: HR4DPulseController, source_template, pulse_runner: Callable[[Any, HR4DPulseTransaction], Any],
  343:     *, interpulse_failure_injector: Callable[[int, int], None] | None = None,
  344: ) -> dict[str, object]:
  345:     """Run or resume the deterministic PRE -> POST -> PRE lifecycle."""
  346:     pulse_calls = interpulse_calls = 0
  347:     last_pulse_result = None
  348:     while not controller.is_complete:
  349:         if controller.next_action == "pulse":
  350:             last_pulse_result = run_one_pulse_transition(controller, source_template, pulse_runner)
  351:             pulse_calls += 1
  352:         else:
  353:             controller.run_interpulse_transition(failure_injector=interpulse_failure_injector)
  354:             interpulse_calls += 1
  355:     return {
  356:         "pulse_calls_this_invocation": pulse_calls,
  357:         "interpulse_calls_this_invocation": interpulse_calls,
  358:         "final_metadata": controller.metadata,
  359:         "last_pulse_result": last_pulse_result,
  360:         "optical_working_field_history_stored": False,
  361:     }
~~~

## hr4c_state.py

~~~text
Lines 132-143:
  132:     def open_existing(
  133:         cls, *, output_path: str, n_intervals: int, shape, dtype, z_edges, dx: float, dy: float,
  134:     ):
  135:         self = cls.__new__(cls)
  136:         self.n_intervals, self.shape, self.dtype = _validate_state_layout(
  137:             n_intervals=n_intervals, shape=shape, dtype=dtype,
  138:         )
  139:         self.state_shape = (self.n_intervals, *self.shape)
  140:         self.output_path = str(output_path)
  141:         self.z_edges = _validate_z_edges(z_edges, self.n_intervals)
  142:         self.dx, self.dy = float(dx), float(dy)
  143:         self.grid_fingerprint = state_fingerprint(
Lines 166-197:
  166:     def initialize_from_legacy_delta_n(
  167:         cls, *, output_path: str, legacy_delta_n_path: str, n_intervals: int, shape, dtype,
  168:         z_edges, dx: float, dy: float, batch_intervals: int,
  169:     ):
  170:         """Create a new three-field generation without modifying legacy HR-3C data."""
  171:         store = cls(
  172:             output_path=output_path, n_intervals=n_intervals, shape=shape, dtype=dtype,
  173:             z_edges=z_edges, dx=dx, dy=dy,
  174:         )
  175:         legacy = np.load(legacy_delta_n_path, mmap_mode="r")
  176:         if legacy.shape != store.state_shape or legacy.dtype != store.dtype:
  177:             store.close()
  178:             raise ValueError("HR-4C legacy delta_n layout does not match requested three-field state")
  179:         batch = int(batch_intervals)
  180:         if batch <= 0:
  181:             store.close()
  182:             raise ValueError("HR-4C batch_intervals must be positive")
  183:         store.begin_staging()
  184:         try:
  185:             for start in range(0, store.n_intervals, batch):
  186:                 stop = min(start + batch, store.n_intervals)
  187:                 values = {
  188:                     "delta_n": np.asarray(legacy[start:stop], dtype=store.dtype),
  189:                     "vx": np.zeros((stop - start, *store.shape), dtype=store.dtype),
  190:                     "vy": np.zeros((stop - start, *store.shape), dtype=store.dtype),
  191:                 }
  192:                 store.write_staging_batch(start, values)
  193:             store.commit_staging({
  194:                 "operation": "legacy_delta_n_initialization",
  195:                 "legacy_delta_n_filename": Path(legacy_delta_n_path).name,
  196:                 "batch_intervals": batch,
  197:             })
Lines 350-376:
  350:     def commit_staging(
  351:         self, evolution: Mapping[str, Any], *, authoritative_metadata: Mapping[str, Any] | None = None,
  352:     ) -> None:
  353:         try:
  354:             batch = int(evolution.get("batch_intervals", 0))
  355:             self.validate_staging(batch_intervals=batch)
  356:             for field in HR4C_FIELDS:
  357:                 self._next[field].flush()
  358:                 _fsync_memmap(self._next[field].filename)
  359:             committed_manifest = dict(self.manifest)
  360:             committed_manifest.update({
  361:                 "transaction_status": "committed",
  362:                 "generation": int(self.manifest["staging_generation"]),
  363:                 "staging_generation": None,
  364:                 "authoritative_filenames": {field: Path(self._next[field].filename).name for field in HR4C_FIELDS},
  365:                 "scratch_filenames": {field: Path(self._current[field].filename).name for field in HR4C_FIELDS},
  366:                 "last_evolution": dict(evolution),
  367:                 "last_abort": None,
  368:             })
  369:             if authoritative_metadata is not None:
  370:                 committed_manifest["authoritative_metadata"] = dict(authoritative_metadata)
  371:             _atomic_json(self.manifest_path, committed_manifest)
  372:         except Exception as error:
  373:             self.abort_staging(reason=type(error).__name__)
  374:             raise
  375:         self._current, self._next = self._next, self._current
  376:         self.manifest = committed_manifest
~~~

## hr4e5s_streaming.py

~~~text
Lines 212-240:
  212: def _atomic_npz(
  213:     path: Path,
  214:     fields: Mapping[str, Any],
  215:     metadata: Mapping[str, Any],
  216:     *,
  217:     before_atomic_rename: Callable[[Path], None] | None = None,
  218: ) -> str:
  219:     path.parent.mkdir(parents=True, exist_ok=True)
  220:     arrays = _validated_fields(fields)
  221:     payload = {name: arrays[name] for name in FIELDS}
  222:     payload["metadata_json"] = np.asarray(json.dumps(metadata, sort_keys=True, separators=(",", ":")))
  223:     descriptor, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
  224:     try:
  225:         with _timed_phase("ARTIFACT_WRITE", artifact=str(path)):
  226:             with os.fdopen(descriptor, "wb") as handle:
  227:                 np.savez(handle, **payload)
  228:                 handle.flush()
  229:                 os.fsync(handle.fileno())
  230:         if before_atomic_rename is not None:
  231:             before_atomic_rename(Path(temporary))
  232:         with _timed_phase("ARTIFACT_ATOMIC_RENAME", artifact=str(path)):
  233:             os.replace(temporary, path)
  234:         _fsync_directory(path.parent)
  235:     except S5FaultInjectedError:
  236:         # F04 models a crash after a durable temporary write.  Its staged file
  237:         # is deliberately retained so formal restart reconstruction, rather
  238:         # than exception cleanup, proves it is non-authoritative.
  239:         raise
  240:     except Exception:
Lines 875-920:
  875:     def commit_post(self, ordinal: int, fields: Mapping[str, Any], *, actor: str = "optical", hr3a_authoritative: bool = True, hr3b_authoritative: bool = True) -> dict[str, Any]:
  876:         with self._locked_manifest():
  877:             record = self._record(ordinal)
  878:             if record["state"] != "DEPOSITION_FINALIZED":
  879:                 raise StreamingLifecycleError("POST commit requires DEPOSITION_FINALIZED")
  880:             if not hr3a_authoritative or not hr3b_authoritative:
  881:                 raise StreamingLifecycleError("POST commit requires authoritative HR-3A and HR-3B")
  882:             if record["post"] is not None:
  883:                 raise DuplicateCommitError("duplicate POST commit")
  884:             with _timed_phase("POST_HOST_PREPARATION", ordinal=int(ordinal)):
  885:                 payload = _validated_fields(fields, shape=self.manifest["shape"], dtype=np.float64)
  886:             with _timed_phase("POST_CANONICAL_HASH", ordinal=int(ordinal)):
  887:                 hashes = _field_hashes(payload)
  888:             metadata = {
  889:                 "schema": SCHEMA, "namespace": "POST", "ordinal": int(ordinal), "screen_id": record["screen_id"], "z_m": record["z_m"],
  890:                 "current_generation": self.manifest["current_generation"], "current_content_sha256": self.manifest["current_content_sha256"],
  891:                 "current_field_sha256": record["current"]["field_sha256"], "field_sha256": hashes,
  892:                 "shape": self.manifest["shape"], "dtype": "float64", "hr3a_authoritative": True, "hr3b_authoritative": True,
  893:             }
  894:             path = self.root / "post" / f"screen_{int(ordinal):06d}.npz"
  895:             self._maybe_inject_s5_fault(
  896:                 "F01_OPTICAL_PRE_POST_COMMIT",
  897:                 ordinal=int(ordinal),
  898:                 lifecycle_stage="OPTICAL_PRE_POST_COMMIT",
  899:             )
  900:             file_hash = _atomic_npz(path, payload, metadata)
  901:             self._maybe_inject_s5_fault(
  902:                 "F09_POST_RENAMED_PRE_MANIFEST",
  903:                 ordinal=int(ordinal),
  904:                 lifecycle_stage="POST_RENAMED_PRE_MANIFEST",
  905:             )
  906:             entry = {"artifact": str(path.relative_to(self.root)), "file_sha256": file_hash, "field_sha256": hashes, "metadata": metadata}
  907:             self._artifact_fields(entry, namespace="POST")
  908:             record["post"] = entry
  909:             committed = time.perf_counter()
  910:             optical_finalized = next((event.get("optical_finalized_s") for event in reversed(record["transitions"]) if event["state"] == "DEPOSITION_FINALIZED"), None)
  911:             self.manifest["rate_events"].append({"ordinal": int(ordinal), "screen_id": record["screen_id"], "z_m": record["z_m"], "event": "POST_COMMITTED", "time_s": committed, "optical_finalized_s": optical_finalized, "queue_depth": len(self.manifest["queue"]), "backpressure": False})
  912:             self._telemetry_locked("POST_COMMITTED", actor=actor, ordinal=ordinal)
  913:             self._transition(record, "POST_COMMITTED", actor=actor, source_file_sha256=record["current"]["file_sha256"], output_file_sha256=file_hash, post_committed_s=committed)
  914:             self._save()
  915:             self._maybe_inject_s5_fault(
  916:                 "F02_POST_COMMITTED_PRE_HYDRO",
  917:                 ordinal=int(ordinal),
  918:                 lifecycle_stage="POST_COMMITTED_PRE_HYDRO",
  919:             )
  920:             return entry
Lines 1047-1073:
 1047:     def commit_next(self, ordinal: int, fields: Mapping[str, Any], *, actor: str = "hydro") -> dict[str, Any]:
 1048:         with self._locked_manifest():
 1049:             record = self._record(ordinal)
 1050:             if record["state"] != "HYDRO_RUNNING" or record["post"] is None:
 1051:                 raise StreamingLifecycleError("NEXT commit requires an owned running POST")
 1052:             if record["next"] is not None:
 1053:                 raise DuplicateCommitError("duplicate NEXT commit")
 1054:             self._begin_hydro_attempt_locked(ordinal, actor=actor)
 1055:             with _timed_phase("NEXT_HOST_PREPARATION", ordinal=int(ordinal)):
 1056:                 payload = _validated_fields(fields, shape=self.manifest["shape"], dtype=np.float64)
 1057:             with _timed_phase("NEXT_CANONICAL_HASH", ordinal=int(ordinal)):
 1058:                 hashes = _field_hashes(payload)
 1059:             metadata = {
 1060:                 "schema": SCHEMA, "namespace": "NEXT", "ordinal": int(ordinal), "screen_id": record["screen_id"], "z_m": record["z_m"],
 1061:                 "current_generation": self.manifest["current_generation"], "current_content_sha256": self.manifest["current_content_sha256"],
 1062:                 "next_generation": self.manifest["next_generation"],
 1063:                 "post_file_sha256": record["post"]["file_sha256"], "post_field_sha256": record["post"]["field_sha256"],
 1064:                 "field_sha256": hashes, "shape": self.manifest["shape"], "dtype": "float64",
 1065:             }
 1066:             path = self.root / "next" / f"screen_{int(ordinal):06d}.npz"
 1067:             file_hash = _atomic_npz(
 1068:                 path,
 1069:                 payload,
 1070:                 metadata,
 1071:                 before_atomic_rename=lambda temporary: self._maybe_inject_s5_fault(
 1072:                     "F04_NEXT_TEMP_PRE_ATOMIC_RENAME",
 1073:                     ordinal=int(ordinal),
Lines 1178-1255:
 1178:     def validate_barrier(self, *, actor: str = "barrier") -> dict[str, Any]:
 1179:         self.record_telemetry("BARRIER_START", actor=actor)
 1180:         with self._locked_manifest():
 1181:             existing = self.manifest.get("barrier")
 1182:             if isinstance(existing, Mapping) and existing.get("status") == "PASS":
 1183:                 self._assert_no_staged_or_orphaned_artifacts()
 1184:                 if self.manifest["queue"] or self.manifest["recovery_backlog"]:
 1185:                     raise BarrierError("stored PASS barrier has unresolved recovery work")
 1186:                 for record in self.manifest["records"]:
 1187:                     if record["state"] != "BARRIER_VALIDATED" or record["post"] is None or record["next"] is None:
 1188:                         raise BarrierError("stored PASS barrier has incomplete lifecycle state")
 1189:                     self._validate_record_provenance(record, require_post=True, require_next=True)
 1190:                 return dict(existing)
 1191:             failures = []
 1192:             seen_next_identities: set[tuple[int, str, float]] = set()
 1193:             try:
 1194:                 self._assert_no_staged_or_orphaned_artifacts()
 1195:             except Exception as error:
 1196:                 failures.append(f"artifact_inventory_{type(error).__name__}:{error}")
 1197:             if self.manifest["queue"]:
 1198:                 failures.append("unresolved_queue")
 1199:             if self.manifest["recovery_backlog"]:
 1200:                 failures.append("unresolved_recovery_backlog")
 1201:             for record in self.manifest["records"]:
 1202:                 if record["state"] != "NEXT_COMMITTED" or record["next"] is None or record["post"] is None:
 1203:                     failures.append(f"screen_{record['ordinal']}_not_next_committed")
 1204:                     continue
 1205:                 try:
 1206:                     self._validate_record_provenance(record, require_post=True, require_next=True)
 1207:                     next_metadata = self._artifact_metadata(record["next"])
 1208:                     identity = (int(next_metadata["ordinal"]), str(next_metadata["screen_id"]), float(next_metadata["z_m"]))
 1209:                     if identity in seen_next_identities:
 1210:                         raise StreamingLifecycleError("duplicate NEXT screen identity")
 1211:                     seen_next_identities.add(identity)
 1212:                 except Exception as error:
 1213:                     failures.append(f"screen_{record['ordinal']}_{type(error).__name__}:{error}")
 1214:             result = {"schema": SCHEMA, "status": "PASS" if not failures else "FAIL", "failures": failures, "expected_screen_count": self.manifest["expected_screen_count"], "validated_utc": _utc(), "current_generation": self.manifest["current_generation"], "next_generation": self.manifest["next_generation"], "current_content_sha256": self.manifest["current_content_sha256"]}
 1215:             self.manifest["barrier"] = result
 1216:             if not failures:
 1217:                 for record in self.manifest["records"]:
 1218:                     self._transition(record, "BARRIER_VALIDATED", actor=actor, source_file_sha256=record["next"]["file_sha256"], output_file_sha256=record["next"]["file_sha256"])
 1219:             self._save()
 1220:             if failures:
 1221:                 self._telemetry_locked("BARRIER_FAIL", actor=actor)
 1222:                 self._save()
 1223:                 raise BarrierError("streaming barrier rejected generation: " + ",".join(failures))
 1224:             self._telemetry_locked("BARRIER_PASS", actor=actor)
 1225:             self._save()
 1226:             return result
 1227: 
 1228:     def promote_next_to_current(self, *, actor: str = "barrier") -> dict[str, Any]:
 1229:         with self._locked_manifest():
 1230:             barrier = self.manifest.get("barrier")
 1231:             if not isinstance(barrier, Mapping) or barrier.get("status") != "PASS":
 1232:                 raise BarrierError("NEXT cannot become CURRENT before barrier PASS")
 1233:             pointer_path = self.root / "authoritative_generation.json"
 1234:             if pointer_path.is_file():
 1235:                 pointer = _read_json(pointer_path)
 1236:                 if self._authoritative_namespace != "NEXT":
 1237:                     raise StreamingLifecycleError("existing promotion pointer is not authoritative")
 1238:                 promotion = self.manifest.get("promotion")
 1239:                 if promotion is None:
 1240:                     # A crash after the durable pointer write but before the
 1241:                     # manifest save completes this one transaction; it never
 1242:                     # writes a second promotion pointer.
 1243:                     self.manifest["promotion"] = pointer
 1244:                     self._telemetry_locked("PROMOTION_RECOVERED", actor=actor)
 1245:                     self._save()
 1246:                 elif dict(promotion) != pointer:
 1247:                     raise StreamingLifecycleError("manifest promotion conflicts with authoritative pointer")
 1248:                 return pointer
 1249:             if self.manifest.get("promotion") is not None:
 1250:                 raise StreamingLifecycleError("manifest records a promotion without its authoritative pointer")
 1251:             pointer = {"schema": SCHEMA, "authoritative_namespace": "NEXT", "source_current_generation": self.manifest["current_generation"], "authoritative_generation": self.manifest["next_generation"], "barrier": dict(barrier), "promoted_utc": _utc(), "actor": actor}
 1252:             _atomic_json(pointer_path, pointer)
 1253:             self._maybe_inject_s5_fault(
 1254:                 "F08_PROMOTION_TRANSACTION_BOUNDARY",
 1255:                 ordinal=int(self.manifest["expected_screen_count"]) - 1,
~~~

## hr4e5s_s3.py

~~~text
Lines 387-398:
  387: def create_streaming_lifecycle(*, input_manifest: Mapping[str, Any], root: str | Path) -> StreamingLifecycle:
  388:     manifest = dict(input_manifest)
  389:     source = np.load(str(manifest["source_state"]), mmap_mode="r", allow_pickle=False)
  390:     try:
  391:         indices = [int(item["source_index"]) for item in manifest["screen_records"]]
  392:         selected = np.asarray(source[indices], dtype=np.float64)
  393:     finally:
  394:         close = getattr(source, "_mmap", None)
  395:         if close is not None:
  396:             close.close()
  397:     zero = np.zeros_like(selected)
  398:     return StreamingLifecycle.create(root=root, current={"delta_n": selected, "vx": zero, "vy": zero}, screen_records=manifest["screen_records"], current_generation=str(manifest["current_generation"]), dx_m=float(manifest["dx_m"]), dy_m=float(manifest["dy_m"]), queue_depth=int(manifest["hydro"]["queue_depth"]), actor="s3_initializer")
~~~

## runner.py

~~~text
Lines 481-504:
  481:     # It is never passed to propagation directly, so every pulse receives an
  482:     # independent working copy while only the slow medium persists.
  483:     E_source = E
  484: 
  485:     dn_gas = xp.zeros((grid.Ny, grid.Nx), dtype=rtype) if not hr3b_enabled else None
  486:     delta_t_pulse = 1.0 / heat.f_rep
  487: 
  488:     t_all = time.perf_counter()
  489:     last_diag = None
  490:     pulse_index_list = []
  491:     pulse_dn_gas_min_list = []
  492:     pulse_dn_gas_max_list = []
  493:     pulse_delta_n_th_min_list = []
  494:     hr3c_diffusion_passes = 0
  495:     hr3c_post_commits = 0
  496:     while hr3c_controller is not None and not bool(hr3c_controller.manifest["run_complete"]):
  497:         if hr3c_controller.manifest["physical_stage"] == "post_pulse":
  498:             hr3c_controller.diffuse_to_next_pre()
  499:             hr3c_diffusion_passes += 1
  500:             continue
  501:         i = int(hr3c_controller.manifest["next_pulse_index"])
  502:         t_p = time.perf_counter()
  503:         E_pulse = E_source.copy()
  504:         transaction = hr3c_controller.begin_pulse()
Lines 540-545:
  540:       for i in range(run.Npulses):
  541:         t_p = time.perf_counter()
  542:         E_pulse = E_source.copy()
  543:         E, Q2D, diag = propagate_one_pulse(
  544:             E_pulse,
  545:             kperp2=axes.kperp2, k0=k0, omega0=omega0,
~~~

## propagate.py

~~~text
Lines 957-963:
  957:         # HR-3B consumes exactly one old, interval-centered state slice here.
  958:         # The in-place update occurs only after this interval's q_thermal exists.
  959:         if thermal_slow_state is not None:
  960:             slow_index_slice = thermal_slow_state.read_interval(interval.index)
  961:         else:
  962:             slow_index_slice = dn_gas
  963:         E = apply_nonlinear(E, phase, alpha_total, dz_try, dn_gas=slow_index_slice, k0=k0)
Lines 1183-1216:
 1183:         if thermal_slow_state is not None:
 1184:             if not bool(thermal_interval["authoritative"]):
 1185:                 raise ValueError("HR-3B requires authoritative HR-3A q_thermal")
 1186:             hr3b_interval = map_post_acoustic_increment(
 1187:                 thermal_interval["q_thermal"],
 1188:                 source_authoritative=True,
 1189:                 rho0=hr3b_parameters["rho0"],
 1190:                 Cv=hr3b_parameters["Cv"],
 1191:                 T0=hr3b_parameters["T0"],
 1192:                 n0=hr3b_parameters["n0"],
 1193:             )
 1194:             state_after = thermal_slow_state.update_interval(
 1195:                 interval.index, hr3b_interval["delta_n_increment"]
 1196:             )
 1197:             hr3b_scalar_ledger.append(
 1198:                 interval.index, hr3b_interval, slow_index_slice, state_after
 1199:             )
 1200:             if hr3b_sink is not None:
 1201:                 hr3b_sink.record_sample(
 1202:                     interval.index,
 1203:                     hr3b_interval["delta_n_increment"],
 1204:                     state_after,
 1205:                 )
 1206:             # S2 infrastructure hook: this is the first point at which the
 1207:             # interval POST source exists and later optical steps cannot alter
 1208:             # it.  Pass an owned host copy only; the hook cannot alias or
 1209:             # mutate the optical field, deposition maps, ledger, or CURRENT.
 1210:             if post_commit_hook is not None:
 1211:                 post_commit_hook(
 1212:                     interval=interval,
 1213:                     state_after=_np.asarray(to_cpu(state_after), dtype=_np.float64).copy(),
 1214:                     hr3a_authoritative=bool(thermal_interval["authoritative"]),
 1215:                     hr3b_authoritative=bool(hr3b_interval["authoritative"]),
 1216:                 )
~~~
